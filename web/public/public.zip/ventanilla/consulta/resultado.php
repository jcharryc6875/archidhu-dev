<?php

	$fecha_transaccion = date("Y-m-d G:i:s");
	$com_recibidas = array();
	require_once __DIR__ . '/icon-captcha/vendor/autoload.php';

	// si el form ha sido enviado, valida el captcha.
	if (!empty($_POST)) 
	{
		session_start();

		// Load the IconCaptcha options.
		$options = require __DIR__ . '/icon-captcha/captcha-config.php';
		// Create an instance of IconCaptcha.
		$captcha = new \IconCaptcha\IconCaptcha($options);
		// Validate the captcha.
		$validation = $captcha->validate($_POST);
		// Confirm the captcha was validated.
		if (!$validation->success()) 
		{
			$result = '<b>Captcha:</b> Validaci&oacute;n fallida con codigo de error:' . $validation->getErrorCode();
			http_response_code(404);
		}
	} 
	else 
	{
		$result = 'El metodo no esta permitido';
		http_response_code(400);
		exit($result);
	}
	//************************************************************************************************
	require_once(dirname(__FILE__).'/../../../../config/ProjectConfiguration.class.php');
	$configuration = ProjectConfiguration::getApplicationConfiguration('backend', 'prod', false);
	sfContext::createInstance($configuration);
	//************************************************************************************************
	$path_theme = sfConfig::get('theme_simad');
	$base_path = sfConfig::get('base_simad');
	$urlApi = $base_path . "public/restapi/ventanilla/v1/%s";
	//************************************************************************************************

	// AUDITORIA...
    //AuditoriaPeer::addNewAuditoria();
	// AUDITORIA... FIN

    $radicado_entrada = '';
    if (isset($_POST['radicado'])) 
    {
        $radicado_entrada = trim($_POST['radicado']);
    }
	else 
	{
		$result = 'El metodo no esta permitido';
		http_response_code(400);
		exit($result);
	}

    if(!empty($radicado_entrada))
    { 
        $com_recibida  = ComRecibidaPeer::getObjectComByRadicadoOrId($radicado_entrada);

        if(!empty($com_recibida))
		{
			$list_users = $com_recibida->getBitacoraHistCom();
			$lista_digit_document = $com_recibida->getListDigitDocument();

			// titulos
			$com_recibidas['RADICADO'] = $com_recibida->getRadicado();
			$com_recibidas['USUARIO_ASIGNADO'] = isset($list_users['destinatario_actual']) ? $list_users['destinatario_actual'] : null;
			$com_recibidas['DEPENDENCIA_ASIGNADA'] = isset($list_users['ndependencia_actual']) ? $list_users['ndependencia_actual'] : null;
			//$com_recibidas['DEPENDENCIA_ASIGNADA'] = isset($list_users['dependencia_actual']) ? $list_users['dependencia_actual'] : null;
			$com_recibidas['USUARIO_RADICADOR'] = isset($list_users['radicador']) ? $list_users['radicador'] : null;
			$com_recibidas['DEPENDENCIA_RADICADOR'] = isset($list_users['dependencia_radicador']) ? $list_users['dependencia_radicador'] : null;
			
			$com_recibidas['FECHA_TRANSACCION'] = $fecha_transaccion;
			$com_recibidas['ISERROR'] = false;
			$com_recibidas['MSG_INFO'] = null;
			//*************************************************************************************************************

			$com_recibidas['ADJUNTOS'] = $lista_digit_document;
			//$com_recibidas['DIGITS'] = 1;

			//*************************************************************************************************************
			$wflist_acom = array();
			foreach ($list_users['eventos_list'] as $item) 
			{
				$wf_evento = array();
				// filas de la tabla
				$wf_evento['RADICADO'] = $com_recibida->getRadicado();
				$wf_evento['DEPENDENCIA'] = isset($item['dependencia']) ? $item['dependencia'] : null;
				$wf_evento['FECHA_ACTIVIDAD'] = isset($item['fecha_recibido']) ? $item['fecha_recibido'] : null;
				$wf_evento['ACTIVIDAD_FLUJO'] = isset($item['proceso']) ? $item['proceso'] : null;
				$wf_evento['USUARIO_ACTIVIDAD'] = isset($item['destinatario']) ? $item['destinatario'] : null;
				$wf_evento['OBSERVACIONES'] = isset($item['observaciones']) ? $item['observaciones'] : null;

				$wflist_acom[] = $wf_evento;
			}
			//*************************************************************************************************************
			$com_recibidas['RADICADO_FLUJO'] = $wflist_acom;

			/* segunda parte */
			$comenviada_id = $com_recibida->getComEnviadaId();
			if(!empty($comenviada_id))
			{
				$com_enviada = ComEnviadaPeer::retrieveByPk($comenviada_id); 
				$bitac_com_enviada = $com_enviada->getBitacoraHistCom();
				$anexos_com_enviada = $com_enviada->getListDigitDocument();
			}
			else
			{
				$com_enviada = null; 
				$bitac_com_enviada = null;
				$anexos_com_enviada = null;
			}
		}
		else
		{
			$com_recibidas = null;
		}
    }
    $includeDiv = false;
    include('_customBodyViews.php');
?>
