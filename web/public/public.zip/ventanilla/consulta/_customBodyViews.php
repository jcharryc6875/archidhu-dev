<?php 
    if($includeDiv)
    {
?>

<div class="col-md-8" id="<?php echo md5('strlistinfo');?>">

<?php 
    }
?>
        <div class="panel panel-success">
                <div class="panel-heading">
                    <div class="panel-title">Lista de Resultados de la Consulta</div>
                </div>
                    <?php 
                    if(empty($com_recibidas))
                    { 
                        ?>

                                <div class="panel-body">
                                    <div class="alert alert-default"><strong>No existen Registros</strong>, Intente con diferentes filtros de consulta.</div>
                                </div>
                                
                        <?php
                    }
                    else
                    {
                        ?>
                        <!-- Informacion Detalle -->
                        <hr />
                            <div class="col-sm-12 col-md-12">  
                                <div class="row">					
                                    <div class="col-sm-6">
                                        <div class="col-sm-4"><p><strong>Radicado:</strong></p></div>
                                        <div class="col-sm-8">
                                            <p>
                                                <?php 

                                                    echo $com_recibidas['RADICADO'] . '  ';

                                                    for ($i = 0; $i < count($com_recibidas); $i++) 
                                                    {
                                                        if ($com_recibidas['ADJUNTOS'][$i]['TIPO_ATTACHMENT'] == 'DIGIT_COM') 
                                                        { 
                                                            //$arrayAnexos[] = $mi_digit_document[$i];
                                                            ?>
                                                            <a class="tooltip-primary" data-toggle="tooltip" data-original-title="<?php // echo basename($result) ?>" href="<?php echo $com_recibidas['ADJUNTOS'][$i]['URL'];?>" target="_blank">
                                                                    <img src="<?php echo $base_path; ?>/images/simad/ico_ver_adj.png" width="25" height="25" align="middle" />   
                                                            </a>
                                                            <?php
                                                            break;
                                                        } 
                                                    }
                                                ?>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="col-sm-5"><p><strong>Usuario Asignado:</strong></p></div>
                                        <div class="col-sm-7"><p><?php echo $com_recibidas['USUARIO_ASIGNADO']; ?></p></div>
                                    </div>
                                </div>

                                <div class="row">					
                                    <div class="col-sm-6">
                                        <div class="col-sm-4"><p><strong>Dependencia Asignada:</strong></p></div>
                                        <div class="col-sm-8">
                                            <p><?php echo $com_recibidas['DEPENDENCIA_ASIGNADA']; ?></p>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="col-sm-5"><p><strong>Usuario Radicador:</strong></p></div>
                                        <div class="col-sm-7"><p><?php echo $com_recibidas['USUARIO_RADICADOR'] ? $com_recibidas['USUARIO_RADICADOR'] : ""; ?></p></div>
                                    </div>
                                </div>

                                <div class="row">					
                                    <div class="col-sm-6">
                                        <div class="col-sm-4"><p><strong>Dependencia Radicador:</strong></p></div>
                                        <div class="col-sm-8">
                                            <p><?php echo $com_recibidas['DEPENDENCIA_RADICADOR']; ?></p>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="col-sm-4"><p><strong>Anexos:</strong></p></div>
                                        <div class="col-sm-8">
                                            <?php 
                                            for ($i = 0; $i < count($com_recibidas['ADJUNTOS']); $i++) 
                                            {
                                                if ($com_recibidas['ADJUNTOS'][$i]["TIPO_ATTACHMENT"] == 'ANEXO') 
                                                { 
                                                    ?>
                                                    <a class="tooltip-primary" data-toggle="tooltip" data-original-title="<?php // echo basename($result) ?>" href="<?php echo $com_recibidas['ADJUNTOS'][$i]['URL'];?>" target="_blank">
                                                            <img src="<?php echo $base_path; ?>/images/simad/ico-adj-file.png" width="25" height="25" align="middle" />   
                                                    </a>
                                                    <?php
                                                } 
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <hr />

                        <div class="panel-body">
                                <table class="table table-bordered table-hover table-striped responsive">
                                    <thead>
                                        <tr>
                                            <th class="text-center" style="width: 15%;">Radicado</th>
                                            <th class="text-center" style="width: 25%;">Dependencia</th>
                                            <th class="text-center" style="width: 10%;">Fecha Actividad</th>
                                            <th class="text-center" style="width: 8%;">Actividad Flujo</th>
                                            <th class="text-center" style="width: 22%;">Usuario Actividad</th>
                                            <th class="text-center" style="width: 20%;">Observaciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                            <?php
                                            //var_dump($com_recibidas);
                                            foreach ($com_recibidas['RADICADO_FLUJO'] as $com_recibida): 
                                            ?>
                                                <tr>
                                                    
                                                    <td class="text-center">
                                                        <?php 
                                                            echo $com_recibida['RADICADO']; 
                                                        ?>
                                                    </td>
                                                    
                                                    <td>
                                                        <?php 
                                                            echo $com_recibida['DEPENDENCIA']; 
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php 
                                                            echo $com_recibida['FECHA_ACTIVIDAD']; 
                                                        ?>
                                                    </td>

                                                    <td>
                                                        <?php 
                                                            echo $com_recibida['ACTIVIDAD_FLUJO']; 
                                                        ?>
                                                    </td>

                                                    <td>
                                                        <?php 
                                                            echo $com_recibida['USUARIO_ACTIVIDAD']; 
                                                        ?>
                                                    </td>

                                                    <td>
                                                        <?php 
                                                            echo $com_recibida['OBSERVACIONES']; 
                                                        ?>
                                                    </td>
                                                </tr>
                                            <?php 
                                            //$con++;$x++;  
                                            endforeach; 
                                            ?>
                                    </tbody>
                                </table>
                        </div>

                        


                    <?php 
                        if(!empty($comenviada_id))
                        {
                    ?> 
                        <!-- SEGUNDA PARTE -->
                        <div class="panel-info" >
                                <div class="panel-heading">
                                    <div class="panel-title">Respuesta Asociada</div>
                                </div>
                                <div style="width:100% clear:both; height:30px;"></div>
                                    <div class="col-sm-12 col-md-12">

                                        <!--  CABEZERAS  -->
                                                    <div class="row">					
                                                        <div class="col-sm-6">
                                                        <div class="col-sm-4"><p><strong>Radicado:</strong></p></div>
                                                        <div class="col-sm-8">
                                                                <p>
                                                                    <?php 

                                                                        echo $com_enviada->getRadicado() . '  ';

                                                                        for ($i = 0; $i < count($anexos_com_enviada); $i++) 
                                                                        {
                                                                            if ($anexos_com_enviada[$i]['TIPO_ATTACHMENT'] == 'DIGIT_COM') 
                                                                            { 
                                                                                //$arrayAnexos[] = $mi_digit_document[$i];
                                                                                ?>
                                                                                <a class="tooltip-primary" data-toggle="tooltip" data-original-title="<?php // echo basename($result) ?>" href="<?php echo $anexos_com_enviada[$i]['URL'];?>" target="_blank">
                                                                                        <img src="<?php echo $base_path; ?>/images/simad/ico_ver_adj.png" width="25" height="25" align="middle" />   
                                                                                </a>
                                                                                <?php
                                                                                break;
                                                                            } 
                                                                        }
                                                                    ?>
                                                                </p>
                                                        </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <div class="col-sm-5"><p><strong>Asunto:</strong></p></div>
                                                            <div class="col-sm-7"><p><?php echo $com_enviada->getAsunto(); ?></p></div>
                                                        </div>
                                                    </div>

                                                    <div class="row">					
                                                        <div class="col-sm-6">
                                                        <div class="col-sm-4"><p><strong>Copias:</strong></p></div>
                                                        <div class="col-sm-8">
                                                            <p><?php echo $bitac_com_enviada['copias']; ?></p>
                                                        </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                        <div class="col-sm-5"><p><strong>Usuario Radicador:</strong></p></div>
                                                        <div class="col-sm-7"><p><?php echo $bitac_com_enviada['radicador'] ? $bitac_com_enviada['radicador'] : ""; ?></p></div>
                                                        </div>
                                                    </div>

                                                    <div class="row">					
                                                            <div class="col-sm-6">
                                                            <div class="col-sm-4"><p><strong>Dependencia Radicador:</strong></p></div>
                                                            <div class="col-sm-8">
                                                                <p><?php echo $bitac_com_enviada['dependencia_radicador']; ?></p>
                                                            </div>
                                                            </div>
                                                            <div class="col-sm-6">
                                                            <div class="col-sm-4"><p><strong>Anexos:</strong></p></div>
                                                            <div class="col-sm-8">
                                                                <?php  

                                                                for ($i = 0; $i < count($anexos_com_enviada); $i++) 
                                                                {
                                                                    if ($anexos_com_enviada[$i]['TIPO_ATTACHMENT'] == 'ANEXO') 
                                                                    { 
                                                                        //$arrayAnexos[] = $mi_digit_document[$i];
                                                                        ?>
                                                                        <a class="tooltip-primary" data-toggle="tooltip" data-original-title="<?php // echo basename($result) ?>" href="<?php echo $anexos_com_enviada[$i]['URL'];?>" target="_blank">
                                                                                <img src="<?php echo $base_path; ?>/images/simad/ico-adj-file.png" width="25" height="25" align="middle" />   
                                                                        </a>
                                                                        <?php
                                                                    } 
                                                                }
                                                                ?>
                                                            </div>
                                                    </div>

                                        <!--  TABLA  -->
                                        <div style="width:100% clear:both; height:50px;"></div>
                                        <div class="panel-body">
                                                <table class="table table-bordered table-hover table-striped responsive">
                                                    <thead>
                                                        <tr>
                                                            <th class="text-center" style="width: 20%;">Destinatario</th>
                                                            <th class="text-center" style="width: 20%;">Dependencia</th>
                                                            <th class="text-center" style="width: 20%;">Fecha Recibido</th>
                                                            <th class="text-center" style="width: 20%;">Fecha Lectura</th>
                                                            <th class="text-center" style="width: 20%;">Proceso</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                            <?php
                                                            //var_dump($com_recibidas);
                                                            foreach ($bitac_com_enviada['eventos_list']  as $losRegistros) :
                                                            ?>
                                                                <tr>
                                                                    <td class="text-center">
                                                                        <?php echo $losRegistros['destinatario']; ?>
                                                                    </td> 

                                                                    <td class="text-center">
                                                                        <?php echo $losRegistros['dependencia']; ?>
                                                                    </td>  
                                                                    
                                                                    <td class="text-center">
                                                                        <?php echo $losRegistros['fecha_recibido']; ?>
                                                                    </td> 

                                                                    <td class="text-center">
                                                                        <?php echo $losRegistros['fecha_lectura']; ?>
                                                                    </td>  
                                                                    
                                                                    <td class="text-center">
                                                                        <?php echo $losRegistros['proceso']; ?>
                                                                    </td> 
                                                                </tr>
                                                            <?php 
                                                            //$con++;$x++;  
                                                            endforeach; 
                                                            ?>
                                                    </tbody>
                                                </table>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    <?php 
                        }
                    ?> 
         <?php
                    }
            ?>
        </div>
<?php 
    if($includeDiv)
    {
?>
</div> 
<?php 
    }
?>
 