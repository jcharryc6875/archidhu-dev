<?php
	require_once(dirname(__FILE__).'/../../../config/ProjectConfiguration.class.php');
	$configuration = ProjectConfiguration::getApplicationConfiguration('backend', 'prod', false);
	sfContext::createInstance($configuration);
    //*************************************************************************************************************************
	function ConsultaPublicacionesWeb($no_radicado)
	{
		$error=false;
		//*********************************************************************************************************************
		$b = new Criteria();
		$b->setDistinct();
		$b->addJoin(ComEnviadaPeer::COMENVIADA_ID, ComRecibidaPeer::COMENVIADA_ID,Criteria::LEFT_JOIN);
		$b->addJoin(ComEnviadaPeer::COMENVIADA_ID,EnviadaUsuarioPeer::COMENVIADA_ID,Criteria::INNER_JOIN);
		//$b->add(ComEnviadaPeer::ES_PUBLICAR,1);
		//$b->add(ComEnviadaPeer::FECHA_MAX_PUBLICACION,date("Y-m-d"), Criteria::GREATER_EQUAL);
		$b->add(ComEnviadaPeer::ESTADODIGITALIZACION_ID,1);
		$b->add(EnviadaUsuarioPeer::ROLUSCOMENVIADA_ID,2);//firma
		$ilist  = ComEnviadaPeer::doSelect($b);
		$respuesta_vars = array();
		//*********************************************************************************************************************
		if(count($ilist) > 0)
		{
			foreach ($ilist as $item)
			{
				$com_recibida = null;
				if($item->getConsecutivoResp()) { $com_recibida = ComRecibidaPeer::retrieveByPK($item->getConsecutivoResp()); }
				//$url = "http://192.9.200.173/simad/enviada.php/com_enviada/viewImage?comenviada_id=".$item->getPrimaryKey()."&vtoken=".$item->getHashPublicacion();
				$url = "http://192.9.200.173/simad/enviada.php/com_enviada/viewImage?comenviada_id=".$item->getPrimaryKey()."&vtoken=".md5($item->getPrimaryKey());
				//$url = 'http://192.9.200.173/simad/enviada.php/com_enviada/viewImage?comenviada_id=';
				$feha_publicacion = "";//$item->getFechaPublicacion("Y-m-d");
				$ciudad = $item->getCiudad();
				$fecha_pqr = "";//$com_recibida != null ? $com_recibida->getFechaPqr("Y-m-d") : "";
				$nro_pqr = "";//$com_recibida != null ? $com_recibida->getNroPqr() : "";
				$radicado = $item->getRadicado();
				$feha_max_publicacion = "";//$item->getFechaMaxPublicacion("Y-m-d");
				$destinatario = "";//(ComEnviada::getDestinatarioCom($item->getPrimaryKey()));
				//$destinatario = "";
				$respuesta_vars[] = array('url' => $url, 'radicado' => $radicado, 'destinatario' => $destinatario, 'ciudad' => $ciudad, 'fecha_pqr' => $fecha_pqr,
										'nro_pqr' => $nro_pqr, 'feha_publicacion' => $feha_publicacion, 'feha_max_publicacion' => $feha_max_publicacion);
				//$respuesta_vars[] = $url.';'.$radicado.';'.$destinatario.';'.$ciudad.';'.$fecha_pqr.';'.$nro_pqr.';'.$feha_publicacion.';'.$feha_max_publicacion;
			}
		}
		else
		{
			$error=true;
			$respuesta_vars[] = 'none;none;none;none;none;none;none;none';
			//$respuesta_vars[] = array('url' => 'none', 'feha_publicacion' => 'none', 'ciudad' => 'none', 'fecha_pqr' => 'none','nro_pqr' => 'none', 'radicado' => 'none', 'feha_max_publicacion' => 'none', 'destinatario' => 'none');
		}            
		//*********************************************************************************************************************
		//return base64_encode(serialize($respuesta_vars));
		return $respuesta_vars;
	}
	
	function ConsultaRadicadoPublic($EntSecurity = array(), $EntComInfo = array())
	{
		$infoxml = file_get_contents("php://input");
		//*********************************************************************************************************************
		$respuesta_vars = array();
		$error = false;
		$fecha_transaccion = date("Y-m-d G:i:s");
		//*********************************************************************************************************************
		try {
			$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
			if($usuario_ws['isError']){
				return responseErrorData($usuario_ws['message']);
			}
			//*****************************************************************************************************************
			$usuario_creador = $usuario_ws['object'];
			$wslog = WebserviceLogPeer::addLogWs("ConsultaRadicadoPublic",$infoxml,null,1,"Consumen Servicio web SGDEA","Ejecuta Exitoso",$usuario_creador->getPrimaryKey());
			//*****************************************************************************************************************
			$radicado_entrada = isset($EntComInfo['RADICADO_ENTRADA']) ? trim($EntComInfo['RADICADO_ENTRADA']) : null;
			$radicado_salida = isset($EntComInfo['RADICADO_SALIDA']) ? trim($EntComInfo['RADICADO_SALIDA']) : null;
			$numero_identificacion = isset($EntComInfo['NUMERO_IDENTIFICACION']) ? trim($EntComInfo['NUMERO_IDENTIFICACION']) : null;
			$numero_expediente = isset($EntComInfo['NUMERO_EXPEDIENTE']) ? trim($EntComInfo['NUMERO_EXPEDIENTE']) : null;
			$radicado_origen = isset($EntComInfo['RADICADO_ORIGEN']) ? trim($EntComInfo['RADICADO_ORIGEN']) : null;
			//*****************************************************************************************************************
			$anyParamValid = false;
			if(!empty($radicado_entrada)){ $anyParamValid = true; }
			if(!empty($radicado_salida)){ $anyParamValid = true; }
			if(!empty($numero_identificacion)){ $anyParamValid = true; }
			if(!empty($numero_expediente)){ $anyParamValid = true; }
			//*****************************************************************************************************************
			if(!$anyParamValid){ return responseErrorAttachment('Es obligatorio al menos un parametro de consulta'); }
			$direccion_registra = "";$telefono_registra = "";
			//*****************************************************************************************************************
			if(!empty($radicado_entrada)){
				$com_recibida  = ComRecibidaPeer::getObjectComByRadicadoOrId($radicado_entrada);
			}
			//*****************************************************************************************************************
			if(!empty($radicado_salida)){
				$com_enviada  = ComEnviadaPeer::getObjectComByRadicadoOrId($radicado_salida);
			}
			//*****************************************************************************************************************
			$list_comenviadas  = array();$list_comrecibidas  = array();
			if(!empty($numero_identificacion)){
				$interesado = InteresadosPeer::getInteresadoByNuid($numero_identificacion);
				if($interesado != null){
					$list_comenviadas  = ComEnviadaPeer::getListComEnviadasByNuid($numero_identificacion);
					$list_comrecibidas  = ComRecibidaPeer::getListComRecibidasByNuid($numero_identificacion);
				}
			}
			//*****************************************************************************************************************
			if(!empty($com_enviada)){
				$info_img = $com_enviada->getListDigitDocument(true);
				$url_download = null;
				$url_inline = null;
				$list_anexos = array();
				//*********************************************************************************************************
				foreach($info_img as $attach){
					if($attach['TIPO_ATTACHMENT'] == 'DIGIT_COM'){
						$url_download = $attach['URL_DOWNLOAD'];
						$url_inline = $attach['URL'];
					}elseif($attach['TIPO_ATTACHMENT'] == 'ANEXO'){
						$list_anexos[] = array('NOMBRE_ANEXO' => $attach['NOMBRE_ARCHIVO'],'URL_ANEXO' => $attach['URL']);
					}
				}
				//*********************************************************************************************************
				$comenviada_vars['RADICADO'] = $com_enviada->getRadicado();
				$comenviada_vars['FECHA_RADICACION'] = $com_enviada->getFechaCreacion();
				$comenviada_vars['NUMERO_FOLIOS'] = $com_enviada->getFolios();
				$comenviada_vars['DIRECCION_REGISTRADA'] = $direccion_registra;
				$comenviada_vars['TELEFONO_REGISTRADO'] = $telefono_registra;
				$comenviada_vars['URL_RADICADO'] = trim($url_inline) ?: null;
				$comenviada_vars['URL_DOWNLOAD'] = trim($url_download) ?: null;				
				$comenviada_vars['ASUNTO'] = $com_enviada->getAsunto();
				$comenviada_vars['SERVICIOS_RADICADO'] = (ServicioPeer::getListDigitDocument($radicado_salida,$radicado_origen,4));
				$comenviada_vars['ANEXOS_RADICADO'] = $list_anexos;
				$comenviada_vars['ISERROR'] = false;
				$comenviada_vars['MSG_INFO'] = null;
				$comenviada_vars['FECHA_TRANSACCION'] = $fecha_transaccion;
				$respuesta_vars[] = $comenviada_vars;
			}
			//*****************************************************************************************************************
			if(!empty($com_recibida)){
				$info_img = $com_recibida->getListDigitDocument(true);
				$url_download = null;
				$url_inline = null;
				$list_anexos = array();
				//*********************************************************************************************************
				foreach($info_img as $attach){
					if($attach['TIPO_ATTACHMENT'] == 'DIGIT_COM'){
						$url_download = $attach['URL_DOWNLOAD'];
						$url_inline = $attach['URL'];
					}elseif($attach['TIPO_ATTACHMENT'] == 'ANEXO'){
						$list_anexos[] = array('NOMBRE_ANEXO' => $attach['NOMBRE_ARCHIVO'],'URL_ANEXO' => $attach['URL']);
					}
				}
				//*********************************************************************************************************
				$comrecibida_vars['RADICADO'] = $com_recibida->getRadicado();
				$comrecibida_vars['FECHA_RADICACION'] = $com_recibida->getFechaCreacion();
				$comrecibida_vars['NUMERO_FOLIOS'] = $com_recibida->getFolios();
				$comrecibida_vars['DIRECCION_REGISTRADA'] = $direccion_registra;
				$comrecibida_vars['TELEFONO_REGISTRADO'] = $telefono_registra;
				$comrecibida_vars['URL_RADICADO'] = trim($url_inline) ?: null;
				$comrecibida_vars['URL_DOWNLOAD'] = trim($url_download) ?: null;
				$comrecibida_vars['ASUNTO'] = $com_recibida->getAsunto();
				$comrecibida_vars['SERVICIOS_RADICADO'] = array();
				$comrecibida_vars['ANEXOS_RADICADO'] = $list_anexos;
				$comrecibida_vars['ISERROR'] = false;
				$comrecibida_vars['MSG_INFO'] = null;
				$comrecibida_vars['FECHA_TRANSACCION'] = $fecha_transaccion;
				$respuesta_vars[] = $comrecibida_vars;
			}
			//*****************************************************************************************************************
			if(!empty($list_comenviadas)){
				foreach ($list_comenviadas as $item){
					$info_img = $item->getListDigitDocument(true);
					$url_download = null;
					$url_inline = null;
					$list_anexos = array();
					//*********************************************************************************************************
					foreach($info_img as $attach){
						if($attach['TIPO_ATTACHMENT'] == 'DIGIT_COM'){
							$url_download = $attach['URL_DOWNLOAD'];
							$url_inline = $attach['URL'];
						}elseif($attach['TIPO_ATTACHMENT'] == 'ANEXO'){
							$list_anexos[] = array('NOMBRE_ANEXO' => $attach['NOMBRE_ARCHIVO'],'URL_ANEXO' => $attach['URL']);
						}
					}
					//*********************************************************************************************************
					$comenviada_vars['RADICADO'] = $item->getRadicado();
					$comenviada_vars['FECHA_RADICACION'] = $item->getFechaCreacion();
					$comenviada_vars['NUMERO_FOLIOS'] = $item->getFolios();
					$comenviada_vars['DIRECCION_REGISTRADA'] = $direccion_registra;
					$comenviada_vars['TELEFONO_REGISTRADO'] = $telefono_registra;
					$comenviada_vars['URL_RADICADO'] = trim($url_inline) ?: null;
					$comenviada_vars['URL_DOWNLOAD'] = trim($url_download) ?: null;
					$comenviada_vars['ASUNTO'] = $item->getAsunto();
					$comenviada_vars['SERVICIOS_RADICADO'] = (ServicioPeer::getListDigitDocument($item->getRadicado(),null,4));
					$comenviada_vars['ANEXOS_RADICADO'] = $list_anexos;
					$comenviada_vars['ISERROR'] = false;
					$comenviada_vars['MSG_INFO'] = null;
					$comenviada_vars['FECHA_TRANSACCION'] = $fecha_transaccion;
					$respuesta_vars[] = $comenviada_vars;
				}
			}
			//*****************************************************************************************************************
			if(!empty($list_comrecibidas)){
				foreach ($list_comrecibidas as $item){
					$info_img = $item->getListDigitDocument(true);
					$url_download = null;
					$url_inline = null;
					$list_anexos = array();
					//*********************************************************************************************************
					foreach($info_img as $attach){
						if($attach['TIPO_ATTACHMENT'] == 'DIGIT_COM'){
							$url_download = $attach['URL_DOWNLOAD'];
							$url_inline = $attach['URL'];
						}elseif($attach['TIPO_ATTACHMENT'] == 'ANEXO'){
							$list_anexos[] = array('NOMBRE_ANEXO' => $attach['NOMBRE_ARCHIVO'],'URL_ANEXO' => $attach['URL']);
						}
					}
					//*********************************************************************************************************
					$comrecibida_vars['RADICADO'] = $item->getRadicado();
					$comrecibida_vars['FECHA_RADICACION'] = $item->getFechaCreacion();
					$comrecibida_vars['NUMERO_FOLIOS'] = $item->getFolios();
					$comrecibida_vars['DIRECCION_REGISTRADA'] = $direccion_registra;
					$comrecibida_vars['TELEFONO_REGISTRADO'] = $telefono_registra;
					$comrecibida_vars['URL_RADICADO'] = trim($url_inline) ?: null;
					$comrecibida_vars['URL_DOWNLOAD'] = trim($url_download) ?: null;
					$comrecibida_vars['ASUNTO'] = $item->getAsunto();
					$comrecibida_vars['SERVICIOS_RADICADO'] = array();
					$comrecibida_vars['ANEXOS_RADICADO'] = $list_anexos;
					$comrecibida_vars['ISERROR'] = false;
					$comrecibida_vars['MSG_INFO'] = null;
					$comrecibida_vars['FECHA_TRANSACCION'] = $fecha_transaccion;
					$respuesta_vars[] = $comrecibida_vars;
				}
			}
			//*****************************************************************************************************************
			if(count($respuesta_vars) == 0){
				$default_vars['RADICADO'] = null;
				$default_vars['FECHA_RADICACION'] = null;
				$default_vars['NUMERO_FOLIOS'] = null;
				$default_vars['DIRECCION_REGISTRADA'] = null;
				$default_vars['TELEFONO_REGISTRADO'] = null;
				$default_vars['URL_RADICADO'] = null;
				$default_vars['URL_DOWNLOAD'] = null;
				$default_vars['ASUNTO'] = null;
				$default_vars['SERVICIOS_RADICADO'] = array();
				$default_vars['ANEXOS_RADICADO'] = array();
				$default_vars['ISERROR'] = true;
				$default_vars['MSG_INFO'] = "No se encontraron registros asociados, con los parametros enviados";
				$default_vars['FECHA_TRANSACCION'] = $fecha_transaccion;
				$respuesta_vars[] = $default_vars;
			}
		} catch (\Throwable $th) {
			$respuesta_vars = array();
			$default_vars['RADICADO'] = null;
			$default_vars['FECHA_RADICACION'] = null;
			$default_vars['NUMERO_FOLIOS'] = null;
			$default_vars['DIRECCION_REGISTRADA'] = null;
			$default_vars['TELEFONO_REGISTRADO'] = null;
			$default_vars['URL_RADICADO'] = null;
			$default_vars['URL_DOWNLOAD'] = null;
			$default_vars['ASUNTO'] = null;
			$default_vars['SERVICIOS_RADICADO'] = array();
			$default_vars['ANEXOS_RADICADO'] = array();
			$default_vars['ISERROR'] = true;
			$default_vars['MSG_INFO'] = $th->getMessage();
			$default_vars['FECHA_TRANSACCION'] = $fecha_transaccion;
			$respuesta_vars[] = $default_vars;
		}
		//*********************************************************************************************************************
		return $respuesta_vars;
	}

	function GetHistoricoRadicado($EntSecurity = array(), $EntComHist = array())
	{
		$respuesta_vars = array();
		$infoxml = file_get_contents("php://input");
		$fecha_transaccion = date("Y-m-d G:i:s");
		$error = false;
		//*********************************************************************************************************************
		try {
			$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
			if($usuario_ws['isError']){ return responseErrorData($usuario_ws['message']); }
			//*****************************************************************************************************************
			$usuario_creador = $usuario_ws['object'];
			$wslog = WebserviceLogPeer::addLogWs("GetHistoricoRadicado",$infoxml,null,1,"Consumen Servicio web SGDEA","Ejecuta Exitoso",$usuario_creador->getPrimaryKey());
			//*****************************************************************************************************************
			$radicado_entrada = isset($EntComHist['RADICADO_ENTRADA']) ? trim($EntComHist['RADICADO_ENTRADA']) : null;
			$radicado_salida = isset($EntComHist['RADICADO_SALIDA']) ? trim($EntComHist['RADICADO_SALIDA']) : null;
			//*****************************************************************************************************************
			$anyParamValid = false;
			if(!empty($radicado_entrada)){ $anyParamValid = true; }
			if(!empty($radicado_salida)){ $anyParamValid = true; }
			//*****************************************************************************************************************
			if(!$anyParamValid){ 
				$respuesta_vars['RADICADO'] = null;
				$respuesta_vars['USUARIO_ASIGNADO'] = null;
				$respuesta_vars['DEPENDENCIA_ASIGNADA'] = null;
				$respuesta_vars['USUARIO_RADICADOR'] = null;
				$respuesta_vars['DEPENDENCIA_RADICADOR'] = null;
				$respuesta_vars['RADICADO_FLUJO'] = array();
				$respuesta_vars['FECHA_TRANSACCION'] = $fecha_transaccion;
				$respuesta_vars['ISERROR'] = true;
				$respuesta_vars['MSG_INFO'] = 'Debe enviar un radicado para consultar';
				//*************************************************************************************************************
				return $respuesta_vars;
			}
			//*****************************************************************************************************************
			if(!empty($radicado_entrada)){ $com_recibida  = ComRecibidaPeer::getObjectComByRadicadoOrId($radicado_entrada); }
			//*****************************************************************************************************************
			if(!empty($radicado_salida)){ $com_enviada  = ComEnviadaPeer::getObjectComByRadicadoOrId($radicado_salida); }
			//*****************************************************************************************************************
			if(!empty($com_enviada)){
				$list_users = $com_enviada->getBitacoraHistCom();
				$respuesta_vars['RADICADO'] = $com_enviada->getRadicado();
				$respuesta_vars['USUARIO_ASIGNADO'] = isset($list_users['destinatario_actual']) ? $list_users['destinatario_actual'] : null;
				$respuesta_vars['DEPENDENCIA_ASIGNADA'] = isset($list_users['dependencia_actual']) ? $list_users['dependencia_actual'] : null;
				$respuesta_vars['USUARIO_RADICADOR'] = isset($list_users['radicador']) ? $list_users['radicador'] : null;
				$respuesta_vars['DEPENDENCIA_RADICADOR'] = isset($list_users['dependencia_radicador']) ? $list_users['dependencia_radicador'] : null;
				$respuesta_vars['FECHA_TRANSACCION'] = $fecha_transaccion;
				$respuesta_vars['ISERROR'] = false;
				$respuesta_vars['MSG_INFO'] = null;
				//*************************************************************************************************************
				$wflist_acom = array();
				foreach ($list_users['eventos_list'] as $item) {
					$wf_evento = array();
					$wf_evento['RADICADO'] = $com_enviada->getRadicado();
					$wf_evento['DEPENDENCIA'] = isset($item['dependencia']) ? $item['dependencia'] : null;
					$wf_evento['FECHA_ACTIVIDAD'] = isset($item['fecha_recibido']) ? $item['fecha_recibido'] : null;
					$wf_evento['ACTIVIDAD_FLUJO'] = isset($item['proceso']) ? $item['proceso'] : null;
					$wf_evento['USUARIO_ACTIVIDAD'] = isset($item['destinatario']) ? $item['destinatario'] : null;
					$wf_evento['OBSERVACIONES'] = isset($item['observaciones']) ? $item['observaciones'] : null;
					$wflist_acom[] = $wf_evento;
				}
				//*************************************************************************************************************
				$respuesta_vars['RADICADO_FLUJO'] = $wflist_acom;
			}
			//*****************************************************************************************************************
			if(!empty($com_recibida)){
				$list_users = $com_recibida->getBitacoraHistCom();
				$respuesta_vars['RADICADO'] = $com_recibida->getRadicado();
				$respuesta_vars['USUARIO_ASIGNADO'] = isset($list_users['destinatario_actual']) ? $list_users['destinatario_actual'] : null;
				$respuesta_vars['DEPENDENCIA_ASIGNADA'] = isset($list_users['dependencia_actual']) ? $list_users['dependencia_actual'] : null;
				$respuesta_vars['USUARIO_RADICADOR'] = isset($list_users['radicador']) ? $list_users['radicador'] : null;
				$respuesta_vars['DEPENDENCIA_RADICADOR'] = isset($list_users['dependencia_radicador']) ? $list_users['dependencia_radicador'] : null;
				$respuesta_vars['FECHA_TRANSACCION'] = $fecha_transaccion;
				$respuesta_vars['ISERROR'] = false;
				$respuesta_vars['MSG_INFO'] = null;
				//*************************************************************************************************************
				$wflist_acom = array();
				foreach ($list_users['eventos_list'] as $item) {
					$wf_evento = array();
					$wf_evento['RADICADO'] = $com_recibida->getRadicado();
					$wf_evento['DEPENDENCIA'] = isset($item['dependencia']) ? $item['dependencia'] : null;
					$wf_evento['FECHA_ACTIVIDAD'] = isset($item['fecha_recibido']) ? $item['fecha_recibido'] : null;
					$wf_evento['ACTIVIDAD_FLUJO'] = isset($item['proceso']) ? $item['proceso'] : null;
					$wf_evento['USUARIO_ACTIVIDAD'] = isset($item['destinatario']) ? $item['destinatario'] : null;
					$wf_evento['OBSERVACIONES'] = isset($item['observaciones']) ? $item['observaciones'] : null;
					$wflist_acom[] = $wf_evento;
				}
				//*************************************************************************************************************
				$respuesta_vars['RADICADO_FLUJO'] = $wflist_acom;
			}
		} catch (\Throwable $th) {
			$respuesta_vars = array();
			$default_vars['RADICADO'] = null;
			$default_vars['FECHA_RADICACION'] = null;
			$default_vars['NUMERO_FOLIOS'] = null;
			$default_vars['DIRECCION_REGISTRADA'] = null;
			$default_vars['TELEFONO_REGISTRADO'] = null;
			$default_vars['URL_RADICADO'] = null;
			$default_vars['ASUNTO'] = null;
			$default_vars['ISERROR'] = true;
			$default_vars['MSG_INFO'] = $th->getMessage();
			$default_vars['FECHA_TRANSACCION'] = $fecha_transaccion;
			$respuesta_vars[] = $default_vars;
		}
		//*********************************************************************************************************************
		return $respuesta_vars;
	}

	function getPuntoRadicacion($EntSecurity = array())
	{
		$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
		if($usuario_ws['isError']){
			return responseErrorData($usuario_ws['message']);
		}
		//*********************************************************************************************************************
		$usuario_creador = $usuario_ws['object'];
		$list_regional = array();
		foreach (RegionalPeer::getAllRegional() as $object)
		{
			$list_regional[] = array('idFielKey' => $object->getPrimaryKey(), 'nombreField' => (strtoupper($object->getDescripcion())));
		}
		//*********************************************************************************************************************
		return $list_regional;
	}

	function getTipoComRecibida($EntSecurity = array())
	{
		$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
		if($usuario_ws['isError']){
			return responseErrorData($usuario_ws['message']);
		}
		//*********************************************************************************************************************
		$list_object = array();
		foreach (TipoComRecibidaPeer::getTipoComRecibidaAll() as $object)
		{
			$list_object[] = array('idFielKey' => $object->getPrimaryKey(), 'nombreField' => (strtoupper($object->getDescripcionCompuesta())));
		}
		//*********************************************************************************************************************
		return $list_object;
	}

	function getFormaRecepcionList()
	{
		$list_object = array();
		foreach (FormaRecepcionPeer::getFormaRecepcionOrderAll() as $object)
		{
			$list_object[] = array('idFielKey' => $object->getPrimaryKey(), 'nombreField' => (strtoupper($object->getDescripcion())));
		}
		//*********************************************************************************************************************
		return $list_object;
	}

	function getPrioridadComList()
	{
		$list_object = array();
		foreach (PrioridadComPeer::getPrioridadComOrderAll() as $object)
		{
			$list_object[] = array('idFielKey' => $object->getPrimaryKey(), 'nombreField' => (strtoupper($object->getDescripcion())));
		}
		//*********************************************************************************************************************
		return $list_object;
	}

	function getEmpresaMensajeriaList()
	{
		$list_object = array();
		foreach (EmpresaMensajeriaPeer::getEmpresaMensajeriaOrderAll() as $object)
		{
			$list_object[] = array('idFielKey' => $object->getPrimaryKey(), 'nombreField' => (strtoupper($object->getNombre())));
		}
		//*********************************************************************************************************************
		return $list_object;
	}

	function getDependenciasList($EntSecurity = array())
	{
		$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
		if($usuario_ws['isError']){
			return responseErrorData($usuario_ws['message']);
		}
		//*********************************************************************************************************************
		$list_object = array();
		foreach (DependenciaPeer::getDependenciaUserLoadList() as $object)
		{
			$nombre_dep = sprintf("%s - %s",trim($object->getCodigo()),(strtoupper($object->getNombre())));
			$list_object[] = array('idFielKey' => $object->getPrimaryKey(), 'codigoField' => trim($object->getCodigo()),'nombreField' => $nombre_dep);
		}
		//*********************************************************************************************************************
		return $list_object;
	}

	function UpdateProcessInfoEntrada($EntSecurity = array(), $consecutivocom_id)
	{
		$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
		if($usuario_ws['isError']){
			return responseErrorData($usuario_ws['message']);
		}
		//*********************************************************************************************************************
		try{
			$com_recibida = ComRecibidaPeer::retrieveByPK($consecutivocom_id);
			if($com_recibida->getTipoprocesocomId() == 1){
				$com_recibida->setFechaDigit(($com_recibida->getFechaDigit() ? $com_recibida->getFechaDigit() : date("Y-m-d G:i:s")));
				$com_recibida->setTipoprocesocomId(2);
				$com_recibida->setIsLocked(0);
				$com_recibida->save();

				$response_default = array (
					'fecha_transaccion' => date("Y-m-d G:i:s"),
					'IsError' => false,
					'MsgError' => 'Actividad realizada con exito'
				);
			}else{
				$response_default = array (
					'fecha_transaccion' => date("Y-m-d G:i:s"),
					'IsError' => true,
					'MsgError' => 'Parametro no encontrado'
				);
			}
		}catch(Exception $ex){
			$response_default = array (
				'fecha_transaccion' => date("Y-m-d G:i:s"),
				'IsError' => true,
				'MsgError' => $ex->getMessage()
			);
		}
		//*********************************************************************************************************************
		return $response_default;
	}

	function getUsuariosList($EntSecurity = array(), $nombre=null,$apellido=null,$dependencia_id=0,$limit_select=25)
	{
		$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
		if($usuario_ws['isError']){
			return responseErrorData($usuario_ws['message']);
		}
		//**********************************************************************************************
		$list_object = array();
		//**********************************************************************************************
		$c = new Criteria();
		$c->setDistinct();
		//**********************************************************************************************
		$c->addJoin(CargoUsuarioPeer::USUARIO_ID,UsuarioPeer::USUARIO_ID);
		$c->addJoin(CargoUsuarioPeer::CARGO_ID,CargoPeer::CARGO_ID);
		$c->addJoin(UsuarioPeer::DEPENDENCIA_ID,DependenciaPeer::DEPENDENCIA_ID);
		$c->addJoin(UsuarioPeer::REGIONAL_ID,RegionalPeer::REGIONAL_ID);
		//**********************************************************************************************
		if(trim($dependencia_id)){
			$c->add(UsuarioPeer::DEPENDENCIA_ID,$dependencia_id);
		}
		//**********************************************************************************************
		if(isset($nombre) && trim($nombre)){
			$c->add(UsuarioPeer::NOMBRE,'%'.trim($nombre).'%',Criteria::LIKE);
		}
		//**********************************************************************************************
		if(isset($apellido) && trim($apellido)){
			$c->add(UsuarioPeer::APELLIDO,'%'.trim($apellido).'%',Criteria::LIKE);
		}
		//**********************************************************************************************
		$c->add(CargoUsuarioPeer::ES_ACTUAL,1);
		$c->add(UsuarioPeer::ESTADOUSUARIO_ID,2,Criteria::NOT_EQUAL);
		$c->addAscendingOrderByColumn(UsuarioPeer::NOMBRE);
		//**********************************************************************************************
		$c->clearSelectColumns();
		$c->addSelectColumn(CargoUsuarioPeer::USUARIO_ID);//0
		$c->addSelectColumn(CargoUsuarioPeer::CARGOUSUARIO_ID);//1
		$c->addSelectColumn(UsuarioPeer::NOMBRE);//2
		$c->addSelectColumn(UsuarioPeer::APELLIDO);//3
		$c->addSelectColumn(CargoPeer::DESCRIPCION);//4
		$c->addSelectColumn(RegionalPeer::DESCRIPCION);//5
		$c->addSelectColumn(DependenciaPeer::CODIGO);//6
		$c->addSelectColumn(DependenciaPeer::NOMBRE);//7
		//**********************************************************************************************
		$resultset = CargoUsuarioPeer::doSelectStmt($c);
		//**********************************************************************************************
		while($object = $resultset->fetch()){
			$list_object[] = array('cargousuario_id' => $object[0], 'usuario_id' => $object[1], 'nombre' => (strtoupper($object[2])),'apellido' => (strtoupper($object[3])),
								'dependencia' => strtoupper(trim($object[6])).' - '.(strtoupper(trim($object[7]))),'cargo' => (strtoupper(trim($object[4]))),'regional' => (strtoupper(trim($object[5]))));
		}
		//*********************************************************************************************************************
		return $list_object;
	}

	function getAreaDestinoList($EntSecurity = array(), $tipoproceso=0)
	{
		$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
		if($usuario_ws['isError']){
			return responseErrorData($usuario_ws['message']);
		}
		//**********************************************************************************************
		$list_object = array();
		//**********************************************************************************************
		$c = new Criteria();
		$c->setDistinct();
		//**********************************************************************************************
		$c->addJoin(CargoUsuarioPeer::USUARIO_ID,UsuarioPeer::USUARIO_ID);
		$c->addJoin(UsuarioPeer::DEPENDENCIA_ID,DependenciaPeer::DEPENDENCIA_ID);
		$c->addJoin(CargoUsuarioPeer::CARGO_ID,CargoPeer::CARGO_ID);
		$c->addJoin(UsuarioPeer::USUARIO_ID,UsuarioProcesocomPeer::USUARIO_ID);
		//**********************************************************************************************
		$c->add(UsuarioProcesocomPeer::TIPOPROCESOCOM_ID,$tipoproceso);
		$c->add(CargoUsuarioPeer::ES_ACTUAL,1);
		//**********************************************************************************************
		$c->addAscendingOrderByColumn(DependenciaPeer::NOMBRE);
		//**********************************************************************************************
		$c->clearSelectColumns();
		$c->addSelectColumn(CargoUsuarioPeer::USUARIO_ID);//0
		$c->addSelectColumn(DependenciaPeer::CODIGO);//1
		$c->addSelectColumn(DependenciaPeer::NOMBRE);//2
		$c->addSelectColumn(CargoUsuarioPeer::CARGOUSUARIO_ID);//3
		//**********************************************************************************************
		try{
		$resultset = CargoUsuarioPeer::doSelectStmt($c);
		//**********************************************************************************************
		while($object = $resultset->fetch()){
			$list_object[] = array('idFielKey' => $object[0], 'idFielKeyCargo' => $object[3], 'codigoField' => trim($object[1]),'nombreField' => sprintf("%s - %s",trim($object[1]),(strtoupper($object[2]))));
		}
		}catch(PropelException $ex){
			return $ex->getMessage();
		}catch(Exception $ex){
			return $ex->getMessage();
		}
		//*********************************************************************************************************************
		return $list_object;
	}

	function getListInteresados($EntSecurity = array(), $nombre="",$apellido="",$numero_identificacion="",$maxResults=25)
	{
		try{
			$logname = sfConfig::get("sf_log_dir").DIRECTORY_SEPARATOR.'request_timed.log';
			//simad_util::writetolog($logname,'UCARGO_DESTINO => '.$EntComRecibida['UCARGO_DESTINO']);
			//simad_util::writetolog($logname,'UCARGO_ORIGEN => '.$EntComRecibida['UCARGO_ORIGEN']);
			$infoxml = file_get_contents("php://input");
			//WebserviceLogPeer::addLogWs("getListInteresados",$infoxml,null,1,"Consumen Servicio web SGDEA","Ejecuta Exitoso",1);
			//*********************************************************************************************************************
			$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
			//return array(array("return" => "Explanation 1"));exit;
    		throw new SoapFault("Server", $usuario_ws['message'], null, $usuario_ws	, "FaultSpecified");
			//return array('Error'=>$usuario_ws['isError']);exit;
			/*if($usuario_ws['isError']){
				$response = v 'interesado_id' => null,
						'ciudad' => null,
						'numero_identificacion' => null,
						'direccion' => null,
						'nombre' => null,
						'isError' => $usuario_ws['isError'],
						'message' => $usuario_ws['message']
				);
				return array($response);
				//return responseErrorData($usuario_ws);
			}*/
			//*********************************************************************************************************************
			$c = new Criteria();
			$c->setLimit($maxResults);
			//*********************************************************************************************************************
			if (isset($nombre)) {    		        
				$c->add(InteresadosPeer::PRIMER_NOMBRE,'%'.trim($nombre).'%',Criteria::LIKE);
			}
			//*********************************************************************************************************************
			if (isset($apellido)) {    		        
				$c->add(InteresadosPeer::PRIMER_APELLIDO,'%'.trim($apellido).'%',Criteria::LIKE);
			}
			//*********************************************************************************************************************
			if (isset($numero_identificacion)) {    		        
				$c->add(InteresadosPeer::NUMERO_IDENTIFICACION,'%'.trim($numero_identificacion).'%',Criteria::LIKE);
			}
			//*********************************************************************************************************************
			$c->addAscendingOrderByColumn(InteresadosPeer::PRIMER_NOMBRE);
			$c->addAscendingOrderByColumn(InteresadosPeer::PRIMER_APELLIDO);
			//*********************************************************************************************************************
			$c->clearSelectColumns();
			$c->addJoin(InteresadosPeer::CIUDAD_ID,CiudadPeer::CIUDAD_ID);
			//*********************************************************************************************************************
			$c->addSelectColumn(InteresadosPeer::INTERESADO_ID);//0
			$c->addSelectColumn(InteresadosPeer::NUMERO_IDENTIFICACION);//1
			$c->addSelectColumn(InteresadosPeer::PRIMER_NOMBRE);//2
			$c->addSelectColumn(InteresadosPeer::SEGUNDO_NOMBRE);//3
			$c->addSelectColumn(InteresadosPeer::PRIMER_APELLIDO);//4
			$c->addSelectColumn(InteresadosPeer::SEGUNDO_APELLIDO);//5
			$c->addSelectColumn(InteresadosPeer::DIRECCION);//6
			$c->addSelectColumn(CiudadPeer::NOMBRE);//7
			//*********************************************************************************************************************
			$resultset = InteresadosPeer::doSelectStmt($c);
			//*********************************************************************************************************************
			$list_object = array();
			while($list_data = $resultset->fetch())
			{
				$row['interesado_id'] = $list_data[0];
				$row['ciudad'] = (strtoupper($list_data[7]));
				$row['numero_identificacion'] = $list_data[1];
				$row['direccion'] = (strtoupper($list_data[6]));
				//*****************************************************************************************************************
				$nombre_compuesto = $list_data[2];
				$nombre_compuesto = $list_data[3] ? $nombre_compuesto." ".$list_data[3] : $nombre_compuesto;
				$nombre_compuesto = $list_data[4] ? $nombre_compuesto." ".$list_data[4] : $nombre_compuesto;
				$nombre_compuesto = $list_data[5] ? $nombre_compuesto." ".$list_data[5] : $nombre_compuesto;
				//*****************************************************************************************************************
				$row['nombre'] = (strtoupper($nombre_compuesto));
				$list_object[] = $row;
			}
			//*********************************************************************************************************************
			//file_put_contents("c:/temp/outputfile.txt", file_get_contents("php://input"));
			$infoxml = file_get_contents("php://input");
			WebserviceLogPeer::addLogWs("getListInteresados",$infoxml,print_r($list_data),1,"Consumen Servicio web SGDEA","Ejecuta Exitoso",1);
			//*********************************************************************************************************************
			return $list_object;
		}catch(PropelException $ex){
			return $ex->getMessage();
		}catch(SoapFault $ex){
			print $ex->faultstring;
		}catch(Exception $ex){
			print $ex->getMessage();
		}
	}

	function getRemitentesList($EntSecurity = array(), $nombre="",$funcionario="",$nuid="",$maxResults=25)
	{
		$c = new Criteria();
		$c->setLimit($maxResults);
		//*********************************************************************************************************************
		if (isset($nombre)) {    		        
			$c->add(DirectorioExternoPeer::NOMBRE,'%'.trim($nombre).'%',Criteria::LIKE);
		}
		//*********************************************************************************************************************
		if (isset($funcionario)) {    		        
			$c->add(DirectorioExternoPeer::FUNCIONARIO,'%'.trim($funcionario).'%',Criteria::LIKE);
		}
		//*********************************************************************************************************************
		if (isset($nuid)) {    		        
			$c->add(DirectorioExternoPeer::NIT,'%'.trim($nuid).'%',Criteria::LIKE);
		}
		//*********************************************************************************************************************
		$c->addAscendingOrderByColumn(DirectorioExternoPeer::NOMBRE);
		//*********************************************************************************************************************
		$c->clearSelectColumns();
		$c->addJoin(DirectorioExternoPeer::CIUDAD_ID,CiudadPeer::CIUDAD_ID);
		//*********************************************************************************************************************
		$c->addSelectColumn(DirectorioExternoPeer::DIRECTORIOEXTERNO_ID);//0
		$c->addSelectColumn(DirectorioExternoPeer::NOMBRE);//1
		$c->addSelectColumn(DirectorioExternoPeer::FUNCIONARIO);//2
		$c->addSelectColumn(DirectorioExternoPeer::NIT);//3
		$c->addSelectColumn(DirectorioExternoPeer::DIRECCION);//4		
		$c->addSelectColumn(CiudadPeer::NOMBRE);//5
		//*********************************************************************************************************************
		try
		{
		$resultset = DirectorioExternoPeer::doSelectStmt($c);
		//*********************************************************************************************************************
		$list_object = array();
		while($list_data = $resultset->fetch())
		{
			$row['directorioexterno_id'] = $list_data[0];
			$row['ciudad'] = (strtoupper($list_data[5]));
			$row['nuid'] = $list_data[3];
			$row['direccion'] = (strtoupper($list_data[4]));
			$row['nombre'] = (strtoupper($list_data[1]));
			$row['funcionario'] = (strtoupper($list_data[2]));
			$list_object[] = $row;
		}
		}catch(PropelException $ex){
			return $ex->getMessage();
		}catch(Exception $ex){
			return $ex->getMessage();
		}
		//*********************************************************************************************************************
		return $list_object;
	}

	function AddRadicadoEntrada($EntSecurity = array(), $EntComRecibida = array(), $EntInteresadoOfList = array() ,$EntRemitente = array())
	{
		//file_put_contents("c:/temp/outputfile.txt", file_get_contents("php://input"));
		$infoxml = file_get_contents("php://input");
		//*******************************************************************************************************************
		try{
			$logname = sfConfig::get("sf_log_dir").DIRECTORY_SEPARATOR.'request_timed.log';
			//***************************************************************************************************************
			$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
			if($usuario_ws['isError']){
				return responseErrorData($usuario_ws['message']);
			}
			//***************************************************************************************************************
			$usuario_creador = $usuario_ws['object'];
			$wslog = WebserviceLogPeer::addLogWs("AddRadicadoEntrada",$infoxml,null,1,"Consumen Servicio web SGDEA","Ejecuta Exitoso",$usuario_creador->getUsuarioId());
			//***************************************************************************************************************
			if(count($EntInteresadoOfList) <= 0){ return responseErrorData('Debe enviar por lo menos un interesado o la información de los interesados no es valida'); }
			//***************************************************************************************************************
			$empresa_mensajeria = -1;
			if(isset($EntComRecibida['EMPRESA_MENSAJERIA'])){
				$courrier_pk = trim($EntComRecibida['EMPRESA_MENSAJERIA']) ? trim($EntComRecibida['EMPRESA_MENSAJERIA']) : 0;
				$empresa_mensajeria = !is_null($courrier_pk) ? EmpresaMensajeriaPeer::retrieveByPK($courrier_pk) : -1;
			}
			//***************************************************************************************************************
			$tipocom_pk = isset($EntComRecibida['CLASIFICACION_DOCUMENTO']) ? trim($EntComRecibida['CLASIFICACION_DOCUMENTO']) : 0;
			$regional_origen = isset($EntComRecibida['REGIONAL_ID']) ? RegionalPeer::retrieveByPK(trim($EntComRecibida['REGIONAL_ID'])) : null;
			$asunto = isset($EntComRecibida['ASUNTO']) ? trim($EntComRecibida['ASUNTO']) : null;
			$folios = isset($EntComRecibida['FOLIOS']) ? trim($EntComRecibida['FOLIOS']) : null;
			//***************************************************************************************************************
			$cuser_destino = CargoUsuarioPeer::retrieveByPK($EntComRecibida['UCARGO_DESTINO']);
			$cuser_origen = CargoUsuarioPeer::retrieveByPK($EntComRecibida['UCARGO_ORIGEN']);
			$tipoprocesocom_id = 2;//distribuidor
			$dependencia_destino = $cuser_destino->getUsuario()->getDependenciaId();
			//***************************************************************************************************************
			if($regional_origen == null){ return responseErrorData('El punto de radicación es un campo obligatorio y no se encontro en el SGDEA'); }
			if(empty($tipocom_pk)){ return responseErrorData('El tipo de documento o trámite es un campo obligatorio o no se encontro en el SGDEA'); }
			if($dependencia_destino == null){ return responseErrorData('La dependencia destino es un campo obligatorio o no se encontro en el SGDEA'); }
			if($asunto == null){ return responseErrorData('El campo asunto es obligatorio'); }
			if($folios == null){ return responseErrorData('El campo folios es obligatorio'); }
			if($empresa_mensajeria == 0){ return responseErrorData('La empresa de mensajeria no esta creada en el SGDEA'); }
			//***************************************************************************************************************
			$params = array();
			$params['regional_id'] = $regional_origen->getPrimaryKey();
			$params['tipocomrecibida_id'] = $tipocom_pk;
			$params['dependencia_id'] = $dependencia_destino;
			$params['formarecepcion_id'] = $EntComRecibida['FORMA_RECEPCION'];
			$params['prioridadcom_id'] = $EntComRecibida['PRIORIDAD_COM'];
			$params['ciudad_id'] = $regional_origen->getCiudadId();
			$params['directorioexterno_id'] = isset($EntComRecibida['REMITENTE_ID']) ? trim($EntComRecibida['REMITENTE_ID']) : null;
			$params['radicado_origen'] = isset($EntComRecibida['RADICADO_ORIGEN']) ? trim($EntComRecibida['RADICADO_ORIGEN']) : null;
			$params['asunto'] = $asunto;
			$params['folios'] = $folios;
			$params['observaciones'] = isset($EntComRecibida['OBSERVACIONES']) ? trim($EntComRecibida['OBSERVACIONES']) : null;
			$params['anexos'] = isset($EntComRecibida['ANEXOS']) ? trim($EntComRecibida['ANEXOS']) : null;
			$params['numero_fud'] = isset($EntComRecibida['NUMERO_FUD']) ? trim($EntComRecibida['NUMERO_FUD']) : null;
			$params['empresamensajeria_id'] = $empresa_mensajeria > 0 ? $empresa_mensajeria->getPrimaryKey() : null;
			$params['numero_guia'] = isset($EntComRecibida['NUMERO_GUIA']) ? trim($EntComRecibida['NUMERO_GUIA']) : null;
			$params['numero_proceso'] = isset($EntComRecibida['NUMERO_PROCESO']) ? trim($EntComRecibida['NUMERO_PROCESO']) : null;
			$params['fecha_vencimiento'] = isset($EntComRecibida['FECHA_VENCIMIENTO']) ? trim($EntComRecibida['FECHA_VENCIMIENTO']) : null;
			$params['fecha_recibido'] = isset($EntComRecibida['FECHA_RECIBIDO']) ? trim($EntComRecibida['FECHA_RECIBIDO']) : null;			
			$params['entidad_id'] = $regional_origen->getEntidadId();
			$params['tipoprocesocom_id'] = $tipoprocesocom_id;
			$params['is_locked'] = 0;
			$params['file'] = null;
			$params['filefullpath'] = true;
			$params['digitOverWrite'] = true;
			//***************************************************************************************************************
			$params['usuario_radicador'] = $cuser_origen->getUsuarioId();
			$params['cusuario_radicador'] = $cuser_origen->getPrimaryKey();
			$params['usuario_destino'] = $cuser_destino->getUsuarioId();
			$params['cusuario_destino'] = $cuser_destino->getPrimaryKey();
			//***************************************************************************************************************
			$com_recibida = ComRecibidaPeer::addComRecibida($params);
			//***************************************************************************************************************
			if(empty($com_recibida)){
				return responseErrorData('No se puedo radicar, ocurrio un error interno en el servidor.');
			}
			//***************************************************************************************************************
			foreach ($EntInteresadoOfList as $info_list) {
				ComrecibidaInteresadosPeer::addNewInteresadoByComId($com_recibida->getPrimaryKey(),$info_list['INTERESADO_ID']);
			}
			//***************************************************************************************************************
			$response_data = array ( 'consecutivo_id' => $com_recibida->getPrimaryKey(),
				'numero_radicacion' => $com_recibida->getNumeroRadicacion(),
				'radicado' => $com_recibida->getRadicado(),
				'fecha_radicacion' => $com_recibida->getFechaCreacion(),
				'dependencia_destino' => (trim($com_recibida->getDependencia()->getNombre())),
				'asunto_com' => (trim($com_recibida->getAsunto())),
				'periodo_id' => $com_recibida->getPeriodoId(),
				'fecha_vencimiento' => $com_recibida->getFechaMaximaRespuesta(),
				'IsError' => false,
				'MsgError' => ''
			);
		}catch(PropelException $ex){
			$response_data = array ( 'consecutivo_id' => 0,
				'numero_radicacion' => 0,
				'radicado' => null,
				'fecha_radicacion' => null,
				'dependencia_destino' => null,
				'asunto_com' => null,
				'periodo_id' => null,
				'fecha_vencimiento' => null,
				'IsError' => true,
				'MsgError' => $ex->getMessage()
			);
		}catch(Exception $ex){
			$response_data = array ( 'consecutivo_id' => 0,
				'numero_radicacion' => 0,
				'radicado' => null,
				'fecha_radicacion' => null,
				'dependencia_destino' => null,
				'asunto_com' => null,
				'periodo_id' => null,
				'fecha_vencimiento' => null,
				'IsError' => true,
				'MsgError' => $ex->getMessage()
			);
		}
		return $response_data;
	}

	function AddRadicadoEntradaPublic($EntSecurity = array(), $EntComRecibida = array(), $ListInteresadoEnt = array(), $EntRemitente = array())
	{
		//file_put_contents("c:/temp/outputfile.txt", file_get_contents("php://input"));
		$infoxml = file_get_contents("php://input");
		//*******************************************************************************************************************
		try{
			$logname = sfConfig::get("sf_log_dir").DIRECTORY_SEPARATOR.'wsentrada_public.log';
			//$filedir_target = sfConfig::get("sf_web_dir").DIRECTORY_SEPARATOR.'uploads'.DIRECTORY_SEPARATOR;
			$dir_raiz = simad_util::NormalizePath(ParametroPeer::retrieveByPk(29)->getValortexto().'uploads');
			$filedir_target = simad_util::createPath($dir_raiz.DIRECTORY_SEPARATOR.date("Ymd")).DIRECTORY_SEPARATOR;
			//***************************************************************************************************************
			$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
			if($usuario_ws['isError']){
				return responseErrorData($usuario_ws['message']);
			}
			//***************************************************************************************************************
			$usuario_creador = $usuario_ws['object'];
			$wslog = WebserviceLogPeer::addLogWs("AddRadicadoEntradaPublic",$infoxml,null,1,"Consumen Servicio web SGDEA","Ejecuta Exitoso",$usuario_creador->getPrimaryKey());
			//***************************************************************************************************************
			$comlist_interesados = array();$laddnew_interesados = array();
			foreach ($ListInteresadoEnt as $info_list) {
				if(simad_util::array_check($info_list,'PRIMER_NOMBRE') && simad_util::array_check($info_list,'PRIMER_APELLIDO') && simad_util::array_check($info_list,'NUMERO_IDENTIFICACION')){
					if(!trim($info_list['NUMERO_IDENTIFICACION'])){
						return responseErrorData('El numero de identificación del interesado no es valido');
					}
					//*******************************************************************************************************
					$interesado_id = InteresadosPeer::existsIntByNameAndNuid(trim($info_list['PRIMER_NOMBRE']),trim($info_list['PRIMER_APELLIDO']),trim($info_list['NUMERO_IDENTIFICACION']));
					if($interesado_id != null){
						$comlist_interesados[] = $interesado_id;
					}elseif(simad_util::array_check($info_list,'TIPO_IDENTIFICACION')){
						//$tipouid_id = TipoIdentificacionPeer::getTipoIdentificacionPkBySigla(trim($info_list['TIPO_IDENTIFICACION']));
						$tipouid_id = TipoIdentificacionPeer::getTipoIdentificacionPkById(trim($info_list['TIPO_IDENTIFICACION']));
						if($tipouid_id == null){
							return responseErrorData('El tipo de identificación del interesado no es un valor valido');
						}
						//***************************************************************************************************
						$info_list['TIPO_IDENTIFICACION'] = $tipouid_id;
						$isValidIntInfo = InteresadosPeer::validateInfoNewInteresado($info_list);
						if($isValidIntInfo['IsValid'] == true){
							$laddnew_interesados[] = $info_list;
						}else{
							return responseErrorData($isValidIntInfo['MsgError']);
							exit;
						}
					}else{
						$info_list['TIPO_IDENTIFICACION'] = 5;
						$isValidIntInfo = InteresadosPeer::validateInfoNewInteresado($info_list);
						if($isValidIntInfo['IsValid'] == true){
							$laddnew_interesados[] = $info_list;
						}else{
							return responseErrorData($isValidIntInfo['MsgError']);
							exit;
						}
					}
				}else{
					return responseErrorData('El nombre o numero de identificación del interesado no es valido');
					exit;
				}
			}
			//***************************************************************************************************************
			if(count($comlist_interesados) <= 0 && count($laddnew_interesados) <= 0){ return responseErrorData('Debe enviar por lo menos un interesado o la información de los interesados no es valida'); }
			//***************************************************************************************************************
			$regional_text = isset($EntComRecibida['REGIONAL_RADICACION']) ? utf8_encode(trim($EntComRecibida['REGIONAL_RADICACION'])) : null;
			$regional_origen = trim($regional_text) ? RegionalPeer::getRegionalByName($regional_text) : null;
			//***************************************************************************************************************
			$tipocom_text = isset($EntComRecibida['TIPO_DOCUMENTO']) ? (trim($EntComRecibida['TIPO_DOCUMENTO'])) : null;
			$tipo_com_recibida = TipoComRecibidaPeer::getTipoComRecibidaByText($tipocom_text);
			//***************************************************************************************************************
			$dependencia_codigo = isset($EntComRecibida['DEPENDENCIA_DESTINO']) ? trim($EntComRecibida['DEPENDENCIA_DESTINO']) : null;
			$dependencia_destino = trim($dependencia_codigo) ? DependenciaPeer::getDependenciaByCodigo($dependencia_codigo) : null;
			//***************************************************************************************************************
			$empresa_mensajeria = -1;
			if(isset($EntComRecibida['EMPRESA_MENSAJERIA'])){
				$courrier_text = trim($EntComRecibida['EMPRESA_MENSAJERIA']) ? utf8_encode(trim($EntComRecibida['EMPRESA_MENSAJERIA'])) : null;
				$empresa_mensajeria = !is_null($courrier_text) ? EmpresaMensajeriaPeer::getEmpresaMensajeriaByName($courrier_text) : -1;
			}
			//***************************************************************************************************************
			$asunto = isset($EntComRecibida['ASUNTO']) ? utf8_encode(trim($EntComRecibida['ASUNTO'])) : null;
			$folios = isset($EntComRecibida['FOLIOS']) ? trim($EntComRecibida['FOLIOS']) : null;
			$adju_b64 = isset($EntComRecibida['ARCHIVO_DIGIT']) ? trim($EntComRecibida['ARCHIVO_DIGIT']) : null;
			$filename_source = isset($EntComRecibida['ARCHIVO_NOMBRE']) ? utf8_encode(trim($EntComRecibida['ARCHIVO_NOMBRE'])) : null;
			//***************************************************************************************************************
			$prioridad_com = isset($EntComRecibida['PRIORIDAD_COM']) ? (trim($EntComRecibida['PRIORIDAD_COM'])) : 1;
			$strforma_recepcion = isset($EntComRecibida['FORMA_RECEPCION']) ? utf8_encode(trim($EntComRecibida['FORMA_RECEPCION'])) : null;
			$forma_recepcion = $strforma_recepcion != null ? FormaRecepcionPeer::getFormaRecepcionByText($strforma_recepcion,true) : null;
			//***************************************************************************************************************
			if($forma_recepcion == null){ return responseErrorData('La forma de recepción('.$strforma_recepcion.') es un campo obligatorio o no se encontro en el SGDEA'); }
			if($regional_origen == null){ return responseErrorData('El punto de radicación es un campo obligatorio y no se encontro en el SGDEA'); }
			if($tipo_com_recibida == null){ return responseErrorData('El tipo de documento o trámite es un campo obligatorio o no se encontro en el SGDEA'); }
			if($dependencia_destino == null){ return responseErrorData('La dependencia destino es un campo obligatorio o no se encontro en el SGDEA'); }
			if($asunto == null){ return responseErrorData('El campo asunto es obligatorio'); }
			if($folios == null){ return responseErrorData('El campo folios es obligatorio'); }
			if($filename_source == null ){ return responseErrorData('El nombre del archivo es un campo obligatorio'); }
			if($adju_b64 == null){ return responseErrorData('Debe enviar el documento digital del radicado de entrada'); }
			if($empresa_mensajeria == 0){ return responseErrorData('La empresa de mensajeria no esta creada en el SGDEA'); }
			if(!is_numeric($prioridad_com)){ return responseErrorData('La prioridad enviada no es valida, debe ser un numero'); }
			//if(!is_int($prioridad_com)){ return responseErrorData('La prioridad enviada no es valida, debe un valor entero'.$prioridad_com); }
			//***************************************************************************************************************
			$mimetypes = explode(";",ParametroPeer::retrieveByPK(31)->getValortexto());			
			$fullpath = $filedir_target.$filename_source;
			$isCreate = simad_util::getConvertB64ToFile($adju_b64,$fullpath);
			//***************************************************************************************************************
			if(!$isCreate){ return responseErrorData('Error interno del servidor al crear el archivo'); }
			//***************************************************************************************************************
			$mime_trust = array('application/pdf', 'application/x-pdf', 'application/x-bzpdf', 'application/x-gzpdf', 'application/zip','application/vnd.ms-outlook');
			$file_valid = simad_util::CheckIsValidFormatFile($fullpath,$mime_trust);
			if(!$file_valid){ return responseErrorData('El formato del archivo no esta permitido'); }
			//***************************************************************************************************************			
			$info_file = new SplFileInfo($fullpath);
			$extension  = strtolower($info_file->getExtension());
			if(!in_array($extension,$mimetypes)){
				unlink($fullpath);
				return responseErrorData('El formato '.$extension.' del archivo no es valido'); 
			}
			//***************************************************************************************************************
			$tipoprocesocom_id = 2;//distribuidor
			if(!$tipo_com_recibida->getTipodistribucionId()){
				$cusuario_destino = UsuarioPeer::getUserDestinoPocesoComByDep($dependencia_destino->getDependenciaId(),$tipoprocesocom_id,true);
			}else{
				$cusuario_destino = ComRecibidaPeer::getConfigReceptorComByDep($dependencia_destino->getDependenciaId(),$tipo_com_recibida->getPrimaryKey(),$tipoprocesocom_id);
				if(is_array($cusuario_destino)){ $cusuario_destino = $cusuario_destino[0]; }
				if($cusuario_destino == null){ $cusuario_destino = UsuarioPeer::getUserDestinoPocesoComByDep($dependencia_destino->getDependenciaId(),$tipoprocesocom_id,true); }
			}
			//***************************************************************************************************************
			if($cusuario_destino == null){ return responseErrorData('El dependencia no tiene parametrizado el usuario distribuidor'); }
			//***************************************************************************************************************
			$cusuario_origen = CargoUsuarioPeer::getCargoUsuarioByIdUser($usuario_creador->getPrimaryKey(),true);
			$EntRemitente['USUARIO_RADICADOR'] = $cusuario_origen->getUsuarioId();
			//***************************************************************************************************************			
			$params = array();
			$params['regional_id'] = $regional_origen->getPrimaryKey();
			$params['tipocomrecibida_id'] = $tipo_com_recibida->getPrimaryKey();
			$params['dependencia_id'] = $dependencia_destino->getPrimaryKey();
			$params['formarecepcion_id'] = $forma_recepcion->getPrimaryKey();
			$params['prioridadcom_id'] = $prioridad_com;
			$params['ciudad_id'] = $regional_origen->getCiudadId();
			$params['directorioexterno_id'] = DirectorioExternoPeer::addNewDirectorioExterno($EntRemitente);
			$params['radicado_origen'] = isset($EntComRecibida['RADICADO_ORIGEN']) ? trim($EntComRecibida['RADICADO_ORIGEN']) : null;
			$params['fecha_vencimiento'] = isset($EntComRecibida['FECHA_VENCIMIENTO']) ? trim($EntComRecibida['FECHA_VENCIMIENTO']) : null;
			$params['fecha_recibido'] = isset($EntComRecibida['FECHA_RECIBIDO']) ? trim($EntComRecibida['FECHA_RECIBIDO']) : null;
			$params['asunto'] = $asunto;
			$params['folios'] = $folios;
			$params['observaciones'] = isset($EntComRecibida['OBSERVACIONES']) ? utf8_encode(trim($EntComRecibida['OBSERVACIONES'])) : null;
			$params['anexos'] = isset($EntComRecibida['ANEXOS']) ? utf8_encode(trim($EntComRecibida['ANEXOS'])) : null;
			$params['numero_fud'] = isset($EntComRecibida['NUMERO_FUD']) ? trim($EntComRecibida['NUMERO_FUD']) : null;
			$params['empresamensajeria_id'] = $empresa_mensajeria > 0 ? $empresa_mensajeria->getPrimaryKey() : null;
			$params['numero_guia'] = isset($EntComRecibida['NUMERO_GUIA']) ? trim($EntComRecibida['NUMERO_GUIA']) : null;
			$params['numero_proceso'] = isset($EntComRecibida['NUMERO_PROCESO']) ? trim($EntComRecibida['NUMERO_PROCESO']) : null;
			$params['entidad_id'] = $regional_origen->getEntidadId();
			$params['tipoprocesocom_id'] = $tipoprocesocom_id;
			$params['is_locked'] = 0;
			$params['file'] = $fullpath;
			$params['filefullpath'] = true;
			$params['digitOverWrite'] = true;
			//***************************************************************************************************************
			$params['usuario_radicador'] = $cusuario_origen->getUsuarioId();
        	$params['cusuario_radicador'] = $cusuario_origen->getPrimaryKey();
        	$params['usuario_destino'] = $cusuario_destino->getUsuarioId();
        	$params['cusuario_destino'] = $cusuario_destino->getPrimaryKey();
			//***************************************************************************************************************
			foreach ($laddnew_interesados as $newitem) {
				$newitem['USUARIO_ID'] = $cusuario_origen->getUsuarioId();
				$interesado_id = InteresadosPeer::addNewInteresado($newitem);
				if($interesado_id == null){ 
					return responseErrorData('Ocurrio un error al crear el interesado en el SGDEA'); 
				}else{
					$comlist_interesados[] = $interesado_id;
				}
			}
			//***************************************************************************************************************
			$com_recibida = ComRecibidaPeer::addComRecibida($params);
			//***************************************************************************************************************
			if(empty($com_recibida)){
				return responseErrorData('No se puedo radicar, ocurrio un error interno en el servidor.');
			}
			//***************************************************************************************************************
			if($wslog != null){
				$wslog->setTipoOperacion("Consumen Servicio web SGDEA => ".$com_recibida->getRadicado());
				$wslog->setMensaje("Ejecuta Exitoso Genera Radicado");
				$wslog->save();
			}
			//***************************************************************************************************************
			//ComRecibidaPeer::envioEmail($com_recibida->getPrimaryKey(),); OJO ENVIAR EMAIL
			//***************************************************************************************************************
			foreach ($comlist_interesados as $item) {
				ComrecibidaInteresadosPeer::addNewInteresadoByComId($com_recibida->getPrimaryKey(),$item);
			}
			//***************************************************************************************************************
			$response_data = array ( 'CONSECUTIVO_ID' => $com_recibida->getPrimaryKey(),				
				'RADICADO' => $com_recibida->getRadicado(),
				'FECHA_RADICACION' => $com_recibida->getFechaCreacion(),				
				'FECHA_VENCIMIENTO' => $com_recibida->getFechaMaximaRespuesta(),
				'FECHA_TRANSACCION' => date("Y-m-d G:i:s"),
				'ISERROR' => false,
				'MSGERROR' => ''
			);
		}catch(PropelException $ex){
			$response_data = array ( 'CONSECUTIVO_ID' => 0,
				'RADICADO' => 0,
				'FECHA_RADICACION' => null,
				'FECHA_VENCIMIENTO' => null,
				'FECHA_TRANSACCION' => date("Y-m-d G:i:s"),
				'ISERROR' => true,
				'MSGERROR' => $ex->getMessage()
			);
		}catch(Exception $ex){
			$response_data = array ( 'CONSECUTIVO_ID' => 0,
				'RADICADO' => 0,
				'FECHA_RADICACION' => null,
				'FECHA_VENCIMIENTO' => null,
				'FECHA_TRANSACCION' => date("Y-m-d G:i:s"),
				'ISERROR' => true,
				'MSGERROR' => $ex->getMessage()
			);
	  	}
		//*******************************************************************************************************************
		return $response_data;
	}

	function responseErrorDataExp($msg, $IsError=true)
	{
		$response = array (
			'CONSECUTIVO_ID' => null,
			'NUMERO_EXPEDIENTE' => null,
			'FECHA_TRANSACCION' => date("Y-m-d G:i:s"),
			'ISERROR' =>  $IsError,
			'MSG_INFO' => $msg
		);

		return $response;
	}
	
	function responseErrorData($msg, $IsError=true)
	{
		$response = array (
			'CONSECUTIVO_ID' => null,
			'RADICADO' => null,
			'FECHA_CREACION' => null,
			'FECHA_TRANSACCION' => date("Y-m-d G:i:s"),
			'ISERROR' =>  $IsError,
			'MSGERROR' => $msg
		);
		return $response;
	}

	function responseErrorAttachment($msg,$IsError=true)
	{
		return array ( 'CONSECUTIVO_ID' => null,
			'RADICADO' => null,
			'FECHA_TRANSACCION' => date("Y-m-d G:i:s"),
			'ISERROR' =>  $IsError,
			'MSG_INFO' => $msg
		);
	}	

	function AddRadicadoSalidaEnt($EntSecurity = array(), $EntComEnviada = array(), $EntInteresadoOfList = array() ,$EntRemitente = array())
	{
		$response_data = array ();
		$fecha_transaccion = date('Y-m-d G:i:s');
		//*********************************************************************************************************************
		$infoxml = file_get_contents("php://input");
		file_put_contents(sfConfig::get("sf_log_dir").DIRECTORY_SEPARATOR.date("Ymd")."_AddRadicadoSalidaOferta.log", $infoxml);
		$util_simad = new simad_util();
		//*******************************************************************************************************************
		try{
			//$filedir_target = sfConfig::get("sf_web_dir").DIRECTORY_SEPARATOR.'uploads'.DIRECTORY_SEPARATOR;
			$dir_raiz = simad_util::NormalizePath(ParametroPeer::retrieveByPk(29)->getValortexto().'uploads');
			$filedir_target = simad_util::createPath($dir_raiz.DIRECTORY_SEPARATOR.date("Ymd")).DIRECTORY_SEPARATOR;
			//$logname = sfConfig::get("sf_log_dir").DIRECTORY_SEPARATOR.'request_timed.log';
			//***************************************************************************************************************
			$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
			if($usuario_ws['isError'])
			{
				return responseErrorData($usuario_ws['message']);
			}
			//***************************************************************************************************************
			$usuario_creador = $usuario_ws['object'];
			$wslog = WebserviceLogPeer::addLogWs("AddRadicadoSalidaEnt",$infoxml,null,1,"Consumen Servicio web SGDEA","Ejecuta Exitoso",$usuario_creador->getUsuarioId());
			//***************************************************************************************************************
			$params = array();
			$periodo_id = isset($EntComEnviada['PERIODO_ID']) ? trim($EntComEnviada['PERIODO_ID']) : date("Y");
			$adju_b64 = isset($EntComEnviada['ARCHIVO_DIGIT']) ? trim($EntComEnviada['ARCHIVO_DIGIT']) : null;
			$filename_source = isset($EntComEnviada['ARCHIVO_NOMBRE']) ? trim($EntComEnviada['ARCHIVO_NOMBRE']) : null;
			$tramite_origen = isset($EntComEnviada['CLASIFICACION_DOCUMENTO']) ? trim($EntComEnviada['CLASIFICACION_DOCUMENTO']) : null;
			$uiduser_origen = isset($EntComEnviada['NUID_RADICA']) ? trim($EntComEnviada['NUID_RADICA']) : trim($EntComEnviada['NUID_GESTOR']);
			$tipo_envio = isset($EntComEnviada['TIPO_ENVIO']) ? trim($EntComEnviada['TIPO_ENVIO']) : null;
			//***************************************************************************************************************
			$object_list = $EntComEnviada['FIRMAS'];
			$cuser_firma = array();
			foreach($object_list as $ufirma_list)
			{
				if(is_array($ufirma_list))
				{
					foreach($ufirma_list as $xufirma)
					{
						$var_ccfirma = !empty($xufirma) ? trim($xufirma) : -1;
						$usuario_firma = CargoUsuarioPeer::getCargoUsuarioByNuidUser($var_ccfirma,true);
						//***************************************************************************************************
						if($usuario_firma == null)
						{
							return responseErrorData('El usuario con cedula '.$var_ccfirma.', que firma el oficio no se encontro en el SGDEA');
						}
						else
						{
							$cuser_firma[] = $usuario_firma;
							$nuid_firma = $var_ccfirma;
						}
					}
				}
				elseif(trim($ufirma_list))
				{
					$usuario_firma = CargoUsuarioPeer::getCargoUsuarioByNuidUser(trim($ufirma_list),true);
					$nuid_firma = trim($ufirma_list);
				}
				else
				{
					$usuario_firma = null;
					$nuid_firma = "(unidefined)";
				}
				//***********************************************************************************************************
				if($usuario_firma == null)
				{
					return responseErrorData('El usuario con cedula '.$nuid_firma.', que firma el oficio no se encontro en el SGDEA');
				}
				else
				{
					$cuser_firma[] = $usuario_firma;
				}
			}
			$cuser_firma = array_unique($cuser_firma);
			//***************************************************************************************************************
			$comlist_interesados = array();$laddnew_interesados = array();$interesados_nuids = array();
			foreach ($EntInteresadoOfList as $info_list) 
			{
				if(simad_util::array_check($info_list,'PRIMER_NOMBRE') && simad_util::array_check($info_list,'PRIMER_APELLIDO') && simad_util::array_check($info_list,'NUMERO_IDENTIFICACION'))
				{
					if(!trim($info_list['NUMERO_IDENTIFICACION']))
					{
						return responseErrorData('El numero de identificación del interesado no es valido');
						exit;
					}
					//********************************************************************************************************
					$interesados_nuids[] = trim($info_list['NUMERO_IDENTIFICACION']);
					//********************************************************************************************************
					$interesado_id = InteresadosPeer::existsIntByNameAndNuid($info_list['PRIMER_NOMBRE'],$info_list['PRIMER_APELLIDO'],$info_list['NUMERO_IDENTIFICACION']);
					if($interesado_id != null)
					{
						$comlist_interesados[] = $interesado_id;
					}
					elseif(simad_util::array_check($info_list,'TIPO_IDENTIFICACION'))
					{
						$tipouid_id = TipoIdentificacionPeer::getTipoIdentificacionPkBySigla(trim($info_list['TIPO_IDENTIFICACION']));
						if($tipouid_id == null)
						{
							return responseErrorData('El tipo de identificación del interesado no es un valor valido');
						}
						//****************************************************************************************************
						$info_list['TIPO_IDENTIFICACION'] = $tipouid_id;
						$isValidIntInfo = InteresadosPeer::validateInfoNewInteresado($info_list);
						if($isValidIntInfo['IsValid'] == true)
						{
							$laddnew_interesados[] = $info_list;
						}
						else
						{
							return responseErrorData($isValidIntInfo['MsgError']);
							exit;
						}
					}
					else
					{
						$info_list['TIPO_IDENTIFICACION'] = 5;
						$isValidIntInfo = InteresadosPeer::validateInfoNewInteresado($info_list);
						if($isValidIntInfo['IsValid'] == true)
						{
							$laddnew_interesados[] = $info_list;
						}
						else
						{
							return responseErrorData($isValidIntInfo['MsgError']);
							exit;
						}
						//return responseErrorData('El tipo de identificación del interesado es obligatorio');
						//exit;
					}
				}
				else
				{
					return responseErrorData('El nombre o numero de identificación del interesado no es valido');
					exit;
				}
			}
			//***************************************************************************************************************
			if(count($comlist_interesados) <= 0 && count($laddnew_interesados) <= 0)
			{ return responseErrorData('Debe enviar como minimo un interesado'); }
			//***************************************************************************************************************
			$cuser_gestor = CargoUsuarioPeer::getCargoUsuarioByNuidUser(trim($EntComEnviada['NUID_GESTOR']),true);
			//***************************************************************************************************************			
			$cuser_origen = $usuario_creador != null ? $usuario_creador : CargoUsuarioPeer::getCargoUsuarioByNuidUser($uiduser_origen,true);
			$regional_origen = isset($EntComEnviada['PUNTO_RADICACION']) ? RegionalPeer::getRegionalByName(trim($EntComEnviada['PUNTO_RADICACION'])) : null;
			//***************************************************************************************************************
			if(empty($cuser_gestor) || is_null($cuser_gestor))
			{
				$cuser_gestor = $cuser_firma[0];
			}
			//***************************************************************************************************************
			$ciudad = isset($EntComEnviada['CODIGO_MUNICIPIO']) ? CiudadPeer::getCiudadByNombAndCod(null,trim($EntComEnviada['CODIGO_MUNICIPIO'])) : null;
			$asunto = isset($EntComEnviada['ASUNTO']) ? trim($EntComEnviada['ASUNTO']) : null;
			$estado_enviada = 1;//borrador estado inicial
			$radicado_entrada = isset($EntComEnviada['RADICADO_ENTRADA']) ? trim($EntComEnviada['RADICADO_ENTRADA']) : null;
			$entrada_externa = isset($EntComEnviada['ENTRADA_EXTERNA']) ? trim($EntComEnviada['ENTRADA_EXTERNA']) : null;
			$observaciones = isset($EntComEnviada['OBSERVACIONES_ENVIO']) ? (trim($EntComEnviada['OBSERVACIONES_ENVIO'])) : null;
			//***************************************************************************************************************
			if(count($cuser_firma) <= 0)
			{ return responseErrorData('El usuario que firma el oficio es obligatorio o no se encontro en el SGDEA'); }
			//if($cuser_origen == null){ responseErrorData('El usuario que radica el oficio es obligatorio o no se encontro en el SGDEA'); }
			//***************************************************************************************************************
			if(empty($cuser_gestor) || is_null($cuser_gestor))
			{
				$msg_text = 'El usuario gestor del oficio esta inactivo o no se encuentra registrado en el SGDEA';
				$user_info = CargoUsuarioPeer::getCargoUsuarioByNuidUserEx(trim($EntComEnviada['NUID_GESTOR']),true);
				if($user_info['error'] == 200)
				{
					$msg_text = 'Ocurrio un error con el usuario gestor del oficio en el SGDEA';
				}
				elseif($user_info['error'] == 400)
				{
					$msg_text = sprintf('Ocurrio un error interno en el SGDEA(%s => %s)',$user_info['message'],$user_info['info']);
				}
				elseif($user_info['error'] == 401)
				{
					$cusuario_gestor = $user_info['object'];
					$msg_text = sprintf('El usuario gestor(%s) del oficio esta (%s) en el SGDEA',$cusuario_gestor->getUsuario()->getFullNombre(),$user_info['info']);
				}
				//***********************************************************************************************************
				return responseErrorData($msg_text); 
			}
			//***************************************************************************************************************
			if(empty($radicado_entrada) && empty($entrada_externa)){ return responseErrorData('El radicado de entrada es obligatorio'); }
			//if($regional_origen == null){ responseErrorData('El punto de radicacion es obligatorio o no se encontro en el SGDEA'); }
			if($ciudad == null){ return responseErrorData('El municipio es obligatorio o no se encontro en el SGDEA'); }
			if($adju_b64 == null){ return responseErrorData('Debe enviar el documento digital del oficio'); }
			if($asunto == null){ return responseErrorData('El asunto es obligatorio'); }
			if($tipo_envio == null){ return responseErrorData('El tipo de envio es un campo obligatorio'); }
			if($filename_source == null ){ return responseErrorData('El nombre del archivo es un campo obligatorio'); }
			//***************************************************************************************************************
			$IsEntadaExterna = false;
			if(!empty($radicado_entrada))
			{
				$com_recibida = ComRecibidaPeer::getComObjectByRadicado($radicado_entrada);
				if($com_recibida == null ){ return responseErrorData('El radicado de entrada no existe en el SGDEA'); }
			}
			elseif(!empty($entrada_externa))
			{
				$IsEntadaExterna = true;
				$observaciones = $observaciones ? sprintf("%s, Radicado Origen => %s",$observaciones,$entrada_externa) :  sprintf("Radicado Origen => %s",$entrada_externa);
			}
			else
			{
				return responseErrorData('El radicado de entrada no existe en el SGDEA');
			}
			//***************************************************************************************************************
			$fullpath = $filedir_target.utf8_encode($filename_source);
			$isCreate = simad_util::getConvertB64ToFile($adju_b64,$fullpath);
			//***************************************************************************************************************
			if(!$isCreate){ return responseErrorData('Error interno del servidor al crear el archivo'); }
			//***************************************************************************************************************
			$mime_trust = array('application/pdf', 'application/x-pdf', 'application/x-bzpdf', 'application/x-gzpdf');
			$file_valid = simad_util::CheckIsValidFormatFile($fullpath,$mime_trust);
			if(!$file_valid){ return responseErrorData('El formato del archivo no esta permitido'); }
			//***************************************************************************************************************
			$info_file = new SplFileInfo($fullpath);
			//$mimetypes = array("pdf","doc", "docx");
			$mimetypes = array("pdf");
			$extension  = strtolower($info_file->getExtension());
			if(!in_array($extension,$mimetypes))
			{
				unlink($fullpath);
				return responseErrorData('El formato '.$extension.' del archivo no es valido'); 
			}
			//***************************************************************************************************************
			if($regional_origen == null)
			{
				$regional_origen = RegionalPeer::retrieveByPk($cuser_firma[0]->getUsuario()->getRegionalId());
			}
			//***************************************************************************************************************
			$addRemitente = false;$directorio_exteno = null;
			if(count($EntRemitente))
			{
				$nuid_remitente = isset($EntComEnviada['NUID']) ? trim($EntComEnviada['NUID']) : null;
				if($nuid_remitente != null){
					$directorio_exteno = DirectorioExternoPeer::existsDirectorioExterno($EntRemitente);
				}else{
					$addRemitente = false;
				}
			}
			//***************************************************************************************************************
			$directorioexteno_id = !empty($directorio_exteno) ? $directorio_exteno->getPrimaryKey() : null;
			//***************************************************************************************************************
			$params['regional_id'] = $regional_origen->getPrimaryKey();
			$params['dependencia_id'] = $cuser_firma[0]->getUsuario()->getDependenciaId();
			$params['estadocomenviada_id'] = $estado_enviada;			
			$params['ciudad_id'] = $cuser_firma[0]->getUsuario()->getRegional()->getCiudadId();//$ciudad->getPrimaryKey();
			$params['periodo_id'] = date("Y");
			$params['asunto'] = isset($EntComEnviada['ASUNTO']) ? (trim($EntComEnviada['ASUNTO'])) : null;
			$params['folios'] = isset($EntComEnviada['FOLIOS']) ? trim($EntComEnviada['FOLIOS']) : 0;
			$params['observaciones_envio'] = $observaciones;
			$params['consecutivo_resp'] = $com_recibida != null ? $com_recibida->getPrimaryKey() : null;
			$params['firma_electronica'] = isset($EntComEnviada['FIRMA_DIGITAL']) ? trim($EntComEnviada['FIRMA_DIGITAL']) : 0;
			$params['archivo_digit'] = $adju_b64;
			$params['use_membrete'] = isset($EntComEnviada['USE_MEMBRETE']) ? trim($EntComEnviada['USE_MEMBRETE']) : null;
			$params['tipofirmadigital_id'] = isset($EntComEnviada['TIPO_FIRMA']) ? trim($EntComEnviada['TIPO_FIRMA']) : null;
			$params['tipo_envio'] = $tipo_envio;
			$params['tipo_masivo'] = isset($EntComEnviada['TIPO_MASIVO']) ? trim($EntComEnviada['TIPO_MASIVO']) : null;
			$params['tipo_integracion'] = "DEMANDA";
			$params['suborigen'] = isset($EntComEnviada['SUBORIGEN']) ? trim($EntComEnviada['SUBORIGEN']) : null;
			$params['UrlFileWord'] = $fullpath;
			$params['IsCreateWord'] = true;
			$params['numero_resolucion'] = isset($EntComEnviada['NUMERO_RESOLUCION']) ? trim($EntComEnviada['NUMERO_RESOLUCION']) : null;
			//***************************************************************************************************************
			if (isset($EntComEnviada['FECHA_RESOLUCION']))
			{
				try{
					$date = new DateTime($EntComEnviada['FECHA_RESOLUCION']);
					$params['fecha_resolucion'] = $date->format('Y-m-d');
				}catch (Exception $ex){
					$params['fecha_resolucion'] = null;
					return responseErrorData('El formato de la fecha resolucion no es valido '.$ex->getMessage());
				}
			}
			//***************************************************************************************************************
			foreach ($laddnew_interesados as $newitem) {
				$newitem['USUARIO_ID'] = $cuser_origen->getUsuarioId();
				$interesado_id = InteresadosPeer::addNewInteresado($newitem);
				if($interesado_id == null){ 
					return responseErrorData('Ocurrio un error interno creando un interesado en el SGDEA'); 
				}else{
					$comlist_interesados[] = $interesado_id;
				}
			}
			//***************************************************************************************************************
			if(!empty($params['numero_resolucion']))
			{
				$existsComByResol = ComEnviadaPeer::isExistComByNumResolucion($params['numero_resolucion'],$interesados_nuids,null,false);
				if($existsComByResol || !empty($existsComByResol)){
					return responseErrorData('No fue posible radicar la comunicación, existen radicados asociados al numero de resolución y el interesado en el SGDEA, numeros de radicado ('.$existsComByResol.')');
				}
			}
			//***************************************************************************************************************
			$com_enviada = ComEnviadaPeer::addComEnviada($params);
			//***************************************************************************************************************
			if($com_enviada == null){ return responseErrorData('Error interno del servidor SGDEA'); }
			//***************************************************************************************************************
			$comlist_interesados = array_unique($comlist_interesados);
			foreach ($comlist_interesados as $interesado_item) 
			{
				EnviadaInteresadosPeer::addNewInteresadoByComId($com_enviada->getPrimaryKey(),$interesado_item);
			}
			//***************************************************************************************************************
			if(!$IsEntadaExterna && $com_recibida != null)
			{
				foreach ($com_recibida->getComrecibidaInteresadoss() as $interesado_origen) {
					$isAdded = EnviadaInteresadosPeer::addNewInteresadoByComId($com_enviada->getPrimaryKey(),$interesado_origen->getInteresadoId());
					if($isAdded){ $comlist_interesados[] = $interesado_origen->getInteresadoId(); }
				}
			}
			//***************************************************************************************************************
			ComEnviadaPeer::insertaEnviadaUsuarios($cuser_origen->getUsuarioId(),$com_enviada->getPrimaryKey(),1,$cuser_origen->getPrimaryKey(),$estado_enviada);
			ComEnviadaPeer::insertaEnviadaUsuarios($cuser_gestor->getUsuarioId(),$com_enviada->getPrimaryKey(),5,$cuser_gestor->getPrimaryKey(),$estado_enviada,3,0);
			//***************************************************************************************************************
			$estaAsignada = 1;
			foreach ($cuser_firma as $cuser) 
			{
				ComEnviadaPeer::insertaEnviadaUsuarios($cuser->getUsuarioId(),$com_enviada->getPrimaryKey(),2,$cuser->getPrimaryKey(),$estado_enviada,5,$estaAsignada);
				$estaAsignada = 0;
			}
			//***************************************************************************************************************
			$msg_info = array();
			if($com_enviada->getTipoMasivo() == 1)
			{
				$estadocomenviada_id = 2;
				$radicado = $com_enviada->getRadicadoFormat(null,$com_enviada->getRegionalId());
				$com_enviada->setRadicado($radicado);
				$com_enviada->setEstadocomenviadaId($estadocomenviada_id);
				$com_enviada->save();
				//***********************************************************************************************************
				if($wslog != null){
					$wslog->setTipoOperacion("Consumen Servicio web SGDEA => ".$radicado);
					$wslog->setMensaje("Ejecuta Exitoso Genera Radicado");
					$wslog->save();
				}
				//***********************************************************************************************************
				EnviadaUsuarioPeer::updateEstados($com_enviada->getPrimaryKey(),$estadocomenviada_id);
    			EnviadaUsuarioPeer::updateAproFirmaAll($com_enviada->getPrimaryKey(),array(2,4,5));
				//***********************************************************************************************************
				if(($com_enviada->getEstadocomenviadaId() != 1 ) && ($com_enviada->getFirmadoDigital() == 0)){
					$response_firma = $com_enviada->singDocumentProcess();
					$msg_info[] = isset($response_firma['message']) ? trim($response_firma['message']) : "Por favor verique si el documento fue firmado correctamente";
				}
				//***********************************************************************************************************
				if($com_recibida != null ){
					$com_enviada->setResponseComOrigen($cuser_firma[0]->getUsuarioId());
				}
			}elseif($wslog != null)
			{
				$wslog->setTipoOperacion("Consumen Servicio web SGDEA => ".$com_enviada->getPrimaryKey());
				$wslog->setMensaje("Ejecuta Exitoso Genera Consecutivo");
				$wslog->save();
			}
			//***************************************************************************************************************
			if($com_enviada->getTipoEnvio() == 4 && ($com_enviada->getEstadocomenviadaId() != 1 ))
			{
				$tiposervicio_id = TipoServicioPeer::getTipoServicioByTipoEnvioIntegra($com_enviada->getTipoEnvio());
				$response_servicio = $com_enviada->addServicioByCom($cuser_gestor->getUsuarioId(),$tiposervicio_id,$comlist_interesados,$directorioexteno_id);
				//***********************************************************************************************************
				if(!$response_servicio['isError'])
				{
					$servicio = $response_servicio['object'];
					$com_enviada->setServicioId($servicio->getPrimaryKey());
					$com_enviada->setEstadocomenviadaId(6);
					$com_enviada->save();
					//*******************************************************************************************************
					EnviadaUsuarioPeer::updateEstados($com_enviada->getPrimaryKey());
					//*******************************************************************************************************
					$msg_info[] = sprintf('Solicitud de servicio creada con radicado %s', $servicio->getRadicado());
				}
				else
				{
					$msg_info[] = isset($response_servicio['message']) ? trim($response_servicio['message']) : "Error al crear la solicitud de servicio";
				}
			}
			//***************************************************************************************************************
			$response_data = array ( 'CONSECUTIVO_ID' => $com_enviada->getPrimaryKey(),
					'RADICADO' => $com_enviada->getRadicado(),
					'FECHA_CREACION' => $com_enviada->getFechaCreacion(),
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  false,
					'MSGERROR' => implode(", ",$msg_info)
			);
		}
		catch(SoapFault $ex)
		{
			$response_data = array ( 'CONSECUTIVO_ID' => null,
					'RADICADO' => null,
					'FECHA_CREACION' => null,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  true,
					'MSGERROR' => $ex->getMessage()
			);
		}
		catch(Exception $ex)
		{
			$response_data = array ( 'CONSECUTIVO_ID' => null,
					'RADICADO' => null,
					'FECHA_CREACION' => null,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  true,
					'MSGERROR' => $ex->getMessage()
			);
		}catch(Exception $ex){
			$response_data = array ( 'CONSECUTIVO_ID' => null,
					'RADICADO' => null,
					'FECHA_CREACION' => null,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  true,
					'MSGERROR' => $ex->getMessage()
			);
	  	}
		//return array('ComRecibidaInfoEnt' =>$response_data);
		return $response_data;
	}

	function AddRadicadoSalidaOferta($EntSecurity = array(), $EntComEnviada = array(), $EntInteresadoOfList = array() ,$EntRemitente = array())
	{
		$response_data = array ();
		$fecha_transaccion = date('Y-m-d G:i:s');
		//*******************************************************************************************************************
		$infoxml = file_get_contents("php://input");
		//file_put_contents(sfConfig::get("sf_log_dir").DIRECTORY_SEPARATOR."AddRadicadoSalidaOferta.log", file_get_contents("php://input"));
		$util_simad = new simad_util();
		//*******************************************************************************************************************
		try{
			//$filedir_target = sfConfig::get("sf_web_dir").DIRECTORY_SEPARATOR.'uploads'.DIRECTORY_SEPARATOR;
			$dir_raiz = simad_util::NormalizePath(ParametroPeer::retrieveByPk(29)->getValortexto().'uploads');
			$filedir_target = simad_util::createPath($dir_raiz.DIRECTORY_SEPARATOR.date("Ymd")).DIRECTORY_SEPARATOR;
			//$logname = sfConfig::get("sf_log_dir").DIRECTORY_SEPARATOR.'request_timed.log';
			//***************************************************************************************************************
			$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
			if($usuario_ws['isError']){
				return responseErrorData($usuario_ws['message']);
			}
			//***************************************************************************************************************
			$usuario_creador = $usuario_ws['object'];
			$wslog = WebserviceLogPeer::addLogWs("AddRadicadoSalidaOferta",$infoxml,null,1,"Consumen Servicio web SGDEA","Ejecuta Exitoso",$usuario_creador->getUsuarioId());
			//***************************************************************************************************************
			$params = array();
			$periodo_id = isset($EntComEnviada['PERIODO_ID']) ? trim($EntComEnviada['PERIODO_ID']) : date("Y");
			$adju_b64 = isset($EntComEnviada['ARCHIVO_DIGIT']) ? trim($EntComEnviada['ARCHIVO_DIGIT']) : null;
			$filename_source = isset($EntComEnviada['ARCHIVO_NOMBRE']) ? (trim($EntComEnviada['ARCHIVO_NOMBRE'])) : null;
			$tramite_origen = isset($EntComEnviada['CLASIFICACION_DOCUMENTO']) ? trim($EntComEnviada['CLASIFICACION_DOCUMENTO']) : null;
			$uiduser_origen = isset($EntComEnviada['NUID_RADICA']) ? trim($EntComEnviada['NUID_RADICA']) : trim($EntComEnviada['NUID_GESTOR']);
			$tipo_envio = isset($EntComEnviada['TIPO_ENVIO']) ? trim($EntComEnviada['TIPO_ENVIO']) : null;
			$app_origen = isset($EntComEnviada['APP_ORIGEN']) ? trim($EntComEnviada['APP_ORIGEN']) : "";
			//***************************************************************************************************************
			$object_list = $EntComEnviada['FIRMAS'];
			$cuser_firma = array();
			foreach($object_list as $ufirma_list){
				if(is_array($ufirma_list)){
					foreach($ufirma_list as $xufirma)
					{
						$var_ccfirma = !empty($xufirma) ? trim($xufirma) : -1;
						$usuario_firma = CargoUsuarioPeer::getCargoUsuarioByNuidUser($var_ccfirma,true);
						//***************************************************************************************************
						if($usuario_firma == null){
							return responseErrorData('El usuario con cedula '.$var_ccfirma.', que firma el oficio no se encontro en el SGDEA');
						}else{
							$cuser_firma[] = $usuario_firma;
							$nuid_firma = $var_ccfirma;
						}
					}
				}elseif(trim($ufirma_list)){
					//return responseErrorData('Un Firmante '.$ufirma_list);
					$usuario_firma = CargoUsuarioPeer::getCargoUsuarioByNuidUser(trim($ufirma_list),true);
					$nuid_firma = trim($ufirma_list);
				}else{
					$usuario_firma = null;
					$nuid_firma = "(unidefined)";
				}
				//***********************************************************************************************************
				if($usuario_firma == null){
					return responseErrorData('El usuario con cedula '.$nuid_firma.', que firma el oficio no se encontro en el SGDEA');
				}else{
					$cuser_firma[] = $usuario_firma;
				}
			}
			$cuser_firma = array_unique($cuser_firma);
			//***************************************************************************************************************
			$comlist_interesados = array();
			$laddnew_interesados = array();
			$interesados_nuids = array();
			foreach ($EntInteresadoOfList as $info_list) 
			{
				if(simad_util::array_check($info_list,'PRIMER_NOMBRE') && simad_util::array_check($info_list,'PRIMER_APELLIDO') && simad_util::array_check($info_list,'NUMERO_IDENTIFICACION')){
					if(!trim($info_list['NUMERO_IDENTIFICACION']))
					{
						return responseErrorData('El numero de identificación del interesado no es valido');
						exit;
					}
					//********************************************************************************************************
					$interesados_nuids[] = trim($info_list['NUMERO_IDENTIFICACION']);
					//********************************************************************************************************
					$interesado_id = InteresadosPeer::existsIntByNameAndNuid($info_list['PRIMER_NOMBRE'],$info_list['PRIMER_APELLIDO'],$info_list['NUMERO_IDENTIFICACION']);
					if($interesado_id != null)
					{
						$comlist_interesados[] = $interesado_id;
					}
					elseif(simad_util::array_check($info_list,'TIPO_IDENTIFICACION'))
					{
						$tipouid_id = TipoIdentificacionPeer::getTipoIdentificacionPkBySigla(trim($info_list['TIPO_IDENTIFICACION']));
						if($tipouid_id == null)
						{
							return responseErrorData('El tipo de identificación del interesado no es un valor valido');
						}
						//****************************************************************************************************
						$info_list['TIPO_IDENTIFICACION'] = $tipouid_id;
						$optional_fileds = array('TIPO_GENERO' => true,'EMAIL' => true);
						$isValidIntInfo = InteresadosPeer::validateInfoNewInteresado($info_list,$optional_fileds);
						if($isValidIntInfo['IsValid'] == true)
						{
							$laddnew_interesados[] = $info_list;
						}
						else
						{
							return responseErrorData($isValidIntInfo['MsgError']);
							exit;
						}
					}
					else
					{
						$info_list['TIPO_IDENTIFICACION'] = 5;
						$isValidIntInfo = InteresadosPeer::validateInfoNewInteresado($info_list);
						if($isValidIntInfo['IsValid'] == true){
							$laddnew_interesados[] = $info_list;
						}else{
							return responseErrorData($isValidIntInfo['MsgError']);
							exit;
						}
					}
				}else{
					return responseErrorData('El nombre o numero de identificación del interesado no es valido');
					exit;
				}
			}
			//***************************************************************************************************************
			if(count($comlist_interesados) <= 0 && count($laddnew_interesados) <= 0){ return responseErrorData('Debe enviar como minimo un interesado'); }
			//***************************************************************************************************************
			$cuser_origen = $usuario_creador != null ? $usuario_creador : CargoUsuarioPeer::getCargoUsuarioByNuidUser($uiduser_origen,true);
			$cuser_gestor = CargoUsuarioPeer::getCargoUsuarioByNuidUser(trim($EntComEnviada['NUID_GESTOR']),true);
			$regional_origen = isset($EntComEnviada['PUNTO_RADICACION']) ? RegionalPeer::getRegionalByName(trim($EntComEnviada['PUNTO_RADICACION'])) : null;
			//***************************************************************************************************************
			if(empty($cuser_gestor) || is_null($cuser_gestor)){
				$cuser_gestor = $cuser_firma[0];
			}
			//***************************************************************************************************************
			$ciudad = isset($EntComEnviada['CODIGO_MUNICIPIO']) ? CiudadPeer::getCiudadByNombAndCod(null,trim($EntComEnviada['CODIGO_MUNICIPIO'])) : null;
			$asunto = isset($EntComEnviada['ASUNTO']) ? (trim($EntComEnviada['ASUNTO'])) : null;
			$estado_enviada = 1;//borrador estado inicial
			//$com_recibida = ComRecibidaPeer::getComObjectByRadicado(trim($EntComEnviada['RADICADO_ENTRADA']),$periodo_id);
			//***************************************************************************************************************
			if(count($cuser_firma) <= 0){ return responseErrorData('El usuario que firma el oficio es obligatorio o no se encontro en el SGDEA'); }
			//if($cuser_origen == null){ responseErrorData('El usuario que radica el oficio es obligatorio o no se encontro en el SGDEA'); }
			//***************************************************************************************************************
			if(empty($cuser_gestor) || is_null($cuser_gestor))
			{
				$msg_text = 'El usuario gestor del oficio esta inactivo o no se encuentra registrado en el SGDEA';
				$user_info = CargoUsuarioPeer::getCargoUsuarioByNuidUserEx(trim($EntComEnviada['NUID_GESTOR']),true);
				if($user_info['error'] == 200){
					$msg_text = 'Ocurrio un error con el usuario gestor del oficio en el SGDEA';
				}elseif($user_info['error'] == 400){
					$msg_text = sprintf('Ocurrio un error interno en el SGDEA(%s => %s)',$user_info['message'],$user_info['info']);
				}elseif($user_info['error'] == 401){
					$cusuario_gestor = $user_info['object'];
					$msg_text = sprintf('El usuario gestor(%s) del oficio esta (%s) en el SGDEA',$cusuario_gestor->getUsuario()->getFullNombre(),$user_info['info']);
				}
				//***********************************************************************************************************
				return responseErrorData($msg_text); 
			}
			//***************************************************************************************************************
			//if($regional_origen == null){ responseErrorData('El punto de radicacion es obligatorio o no se encontro en el SGDEA'); }
			if($ciudad == null){ return responseErrorData('El municipio es obligatorio o no se encontro en el SGDEA'); }
			if($adju_b64 == null){ return responseErrorData('Debe enviar el documento digital del oficio'); }
			//if(!count($EntInteresadoOfList)){ return responseErrorData('Debe enviar minimo un interesado'); }
			//if(!($EntInteresadoOfList)){ return responseErrorData('Los datos del interesado no son corresctos'); }
			if($asunto == null){ return responseErrorData('El asunto es obligatorio'); }
			if($tipo_envio == null){ return responseErrorData('El tipo de envio es un campo obligatorio'); }
			if($filename_source == null ){ return responseErrorData('El nombre del archivo es un campo obligatorio'); }
			//***************************************************************************************************************
			$file_vars = pathinfo($filedir_target.$filename_source);
			$filename_source = $util_simad->clean_name_file($file_vars);
			$fullpath = $filedir_target.uniqid()."_".utf8_encode($filename_source);
			$isCreate = simad_util::getConvertB64ToFile($adju_b64,$fullpath);
			//***************************************************************************************************************
			if(!$isCreate){ return responseErrorData('Error interno del servidor al crear el archivo'); }
			//***************************************************************************************************************
			$mime_trust = array('application/pdf', 'application/x-pdf', 'application/x-bzpdf', 'application/x-gzpdf');
			$file_valid = simad_util::CheckIsValidFormatFile($fullpath,$mime_trust);
			if(!$file_valid){ return responseErrorData('El formato del archivo no esta permitido'); }
			//***************************************************************************************************************
			$info_file = new SplFileInfo($fullpath);
			//$mimetypes = array("pdf","doc", "docx");
			$mimetypes = array("pdf");
			$extension  = strtolower($info_file->getExtension());
			if(!in_array($extension,$mimetypes)){
				unlink($fullpath);
				return responseErrorData('El formato '.$extension.' del archivo no es valido'); 
			}
			//***************************************************************************************************************
			if($regional_origen == null){
				$regional_origen = RegionalPeer::retrieveByPk($cuser_firma[0]->getUsuario()->getRegionalId());
			}
			//***************************************************************************************************************
			$addRemitente = false;$directorio_exteno = null;
			if(count($EntRemitente)){
				$nuid_remitente = isset($EntComEnviada['NUID']) ? trim($EntComEnviada['NUID']) : null;
				if($nuid_remitente != null){
					$directorio_exteno = DirectorioExternoPeer::existsDirectorioExterno($EntRemitente);
				}else{
					$addRemitente = false;
				}
			}
			//***************************************************************************************************************
			$directorioexteno_id = !empty($directorio_exteno) ? $directorio_exteno->getPrimaryKey() : null;
			//***************************************************************************************************************
			$params['regional_id'] = $regional_origen->getPrimaryKey();
			$params['dependencia_id'] = $cuser_firma[0]->getUsuario()->getDependenciaId();
			$params['estadocomenviada_id'] = $estado_enviada;			
			$params['ciudad_id'] = $cuser_firma[0]->getUsuario()->getRegional()->getCiudadId();//$ciudad->getPrimaryKey();
			$params['periodo_id'] = date("Y");
			$params['asunto'] = $asunto;
			$params['folios'] = isset($EntComEnviada['FOLIOS']) ? trim($EntComEnviada['FOLIOS']) : 0;
			$params['observaciones_envio'] = isset($EntComEnviada['OBSERVACIONES_ENVIO']) ? utf8_encode(trim($EntComEnviada['OBSERVACIONES_ENVIO'])) : null;
			$params['consecutivo_resp'] = null;
			$params['firma_electronica'] = isset($EntComEnviada['FIRMA_DIGITAL']) ? trim($EntComEnviada['FIRMA_DIGITAL']) : 0;
			$params['archivo_digit'] = $adju_b64;
			$params['use_membrete'] = isset($EntComEnviada['USE_MEMBRETE']) ? trim($EntComEnviada['USE_MEMBRETE']) : null;
			$params['tipofirmadigital_id'] = isset($EntComEnviada['TIPO_FIRMA']) ? trim($EntComEnviada['TIPO_FIRMA']) : null;
			$params['tipo_envio'] = $tipo_envio;
			$params['tipo_masivo'] = isset($EntComEnviada['TIPO_MASIVO']) ? trim($EntComEnviada['TIPO_MASIVO']) : 1;
			$params['expediente_id'] = isset($EntComEnviada['EXPEDIENTE_ID']) ? trim($EntComEnviada['EXPEDIENTE_ID']) : null;
			$params['marco_normativo'] = isset($EntComEnviada['MARCO_NORMATIVO']) ? trim($EntComEnviada['MARCO_NORMATIVO']) : null;
			$params['numero_fud'] = isset($EntComEnviada['NUMERO_FUD']) ? trim($EntComEnviada['NUMERO_FUD']) : null;
			//$params['tipo_integracion'] = trim($app_origen) ? "OFERTA - ".$app_origen : "OFERTA";
			$params['tipo_integracion'] = "OFERTA";
			//***************************************************************************************************************
			if (isset($EntComEnviada['FECHA_RESOLUCION'])){
				try{
					$date = new DateTime($EntComEnviada['FECHA_RESOLUCION']);
					$params['fecha_resolucion'] = $date->format('Y-m-d');
				}catch (Exception $ex){
					$params['fecha_resolucion'] = null;
					return responseErrorData('El formato de la fecha resolucion no es valido '.$ex->getMessage());
				}
			} 
			//***************************************************************************************************************
			$params['numero_resolucion'] = isset($EntComEnviada['NUMERO_RESOLUCION']) ? trim($EntComEnviada['NUMERO_RESOLUCION']) : null;
			$params['suborigen'] = isset($EntComEnviada['SUBORIGEN']) ? trim($EntComEnviada['SUBORIGEN']) : null;
			$params['radicado_sys_origen'] = isset($EntComEnviada['NUMRADSYSORIGEN']) ? trim($EntComEnviada['NUMRADSYSORIGEN']) : null;
			$params['tipo_documental_cod'] = isset($EntComEnviada['TIPO_DOCUMENTAL']) ? trim($EntComEnviada['TIPO_DOCUMENTAL']) : null;
			$params['UrlFileWord'] = $fullpath;
			$params['IsCreateWord'] = true;
			//***************************************************************************************************************
			foreach ($laddnew_interesados as $newitem) 
			{
				$newitem['USUARIO_ID'] = $cuser_origen->getUsuarioId();
				$interesado_id = InteresadosPeer::addNewInteresado($newitem);
				if($interesado_id == null){ 
					return responseErrorData('Ocurrio un error al crear el interesado en el SGDEA'); 
				}else{
					$comlist_interesados[] = $interesado_id;
				}
			}
			//***************************************************************************************************************
			if(!empty($params['numero_resolucion'])){
				$existsComByResol = ComEnviadaPeer::isExistComByNumResolucion($params['numero_resolucion'],$interesados_nuids,null,false);
				if($existsComByResol || !empty($existsComByResol)){
					return responseErrorData('No fue posible radicar la comunicación, existen radicados asociados al numero de resolución y el interesado en el SGDEA, numeros de radicado ('.$existsComByResol.')');
				}
			}
			//***************************************************************************************************************
			$com_enviada = ComEnviadaPeer::addComEnviada($params);
			//***************************************************************************************************************
			if($com_enviada == null){ return responseErrorData('Error interno del servidor del SGDEA'); }
			//***************************************************************************************************************
			foreach ($comlist_interesados as $interesado_item) {
				EnviadaInteresadosPeer::addNewInteresadoByComId($com_enviada->getPrimaryKey(),$interesado_item);
			}
			//***************************************************************************************************************
			ComEnviadaPeer::insertaEnviadaUsuarios($cuser_origen->getUsuarioId(),$com_enviada->getPrimaryKey(),1,$cuser_origen->getPrimaryKey(),$estado_enviada);
			ComEnviadaPeer::insertaEnviadaUsuarios($cuser_gestor->getUsuarioId(),$com_enviada->getPrimaryKey(),5,$cuser_gestor->getPrimaryKey(),$estado_enviada,3,0);
			//***************************************************************************************************************
			$estaAsignada = 1;
			foreach ($cuser_firma as $cuser) {
				ComEnviadaPeer::insertaEnviadaUsuarios($cuser->getUsuarioId(),$com_enviada->getPrimaryKey(),2,$cuser->getPrimaryKey(),$estado_enviada,5,$estaAsignada);
				$estaAsignada = 0;
			}
			//***************************************************************************************************************
			$msg_info = array();
			if($com_enviada->getTipoMasivo()){
				$estadocomenviada_id = 2;
				$radicado = $com_enviada->getRadicadoFormat(null,$com_enviada->getRegionalId());
				$com_enviada->setRadicado($radicado);
				$com_enviada->setEstadocomenviadaId($estadocomenviada_id);
				$com_enviada->save();
				//***************************************************************************************************************
				if($wslog != null){
					$wslog->setTipoOperacion("Consumen Servicio web SGDEA => ".$radicado);
					$wslog->setMensaje("Ejecuta Exitoso Genera Radicado");
					$wslog->save();
				}
				//***********************************************************************************************************
				EnviadaUsuarioPeer::updateEstados($com_enviada->getPrimaryKey(),$estadocomenviada_id);
				EnviadaUsuarioPeer::updateAproFirmaAll($com_enviada->getPrimaryKey(),array(2,4,5));
				//***********************************************************************************************************
				if(($com_enviada->getEstadocomenviadaId() != 1 ) && ($com_enviada->getFirmadoDigital() == 0)){
					$response_firma = $com_enviada->singDocumentProcess();
					$msg_info[] = isset($response_firma['message']) ? trim($response_firma['message']) : "Por favor verique la firma digital de documento";
				}
			}elseif($wslog != null){
				$wslog->setTipoOperacion("Consumen Servicio web SGDEA => ".$com_enviada->getPrimaryKey());
				$wslog->setMensaje("Ejecuta Exitoso Genera Consecutivo");
				$wslog->save();
			}
			//***************************************************************************************************************
			if($com_enviada->getTipoEnvio() == 4){
				$tiposervicio_id = TipoServicioPeer::getTipoServicioByTipoEnvioIntegra($com_enviada->getTipoEnvio());
				$response_servicio = $com_enviada->addServicioByCom($cuser_gestor->getUsuarioId(),$tiposervicio_id,$comlist_interesados,$directorioexteno_id);
				//***********************************************************************************************************
				if(!$response_servicio['isError']){
					$servicio = $response_servicio['object'];
					$com_enviada->setServicioId($servicio->getPrimaryKey());
					$com_enviada->setEstadocomenviadaId(6);
					$com_enviada->save();
					//*******************************************************************************************************
					EnviadaUsuarioPeer::updateEstados($com_enviada->getPrimaryKey());
					//*******************************************************************************************************
					$msg_info[] = sprintf('Solicitud de servicio creada con radicado %s', $servicio->getRadicado());
				}else{
					$msg_info[] = isset($response_servicio['message']) ? trim($response_servicio['message']) : "Error al crear la solicitud de servicio";
				}
			}
			//***************************************************************************************************************
			$response_data = array ( 'CONSECUTIVO_ID' => $com_enviada->getPrimaryKey(),
					'RADICADO' => $com_enviada->getRadicado(),
					'FECHA_CREACION' => $com_enviada->getFechaCreacion(),
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  false,
					'MSGERROR' => implode(", ",$msg_info)
			);
		}catch(PropelException $ex){
			$response_data = array ( 'CONSECUTIVO_ID' => null,
					'RADICADO' => null,
					'FECHA_CREACION' => null,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  true,
					'MSGERROR' => 'SoapFault => '.$ex->getMessage()
			);
		}catch(SoapFault $ex){
			$response_data = array ( 'CONSECUTIVO_ID' => null,
					'RADICADO' => null,
					'FECHA_CREACION' => null,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  true,
					'MSGERROR' => 'SoapFault => '.$ex->getMessage()
			);
		}catch(Exception $ex){
			$response_data = array ( 'CONSECUTIVO_ID' => null,
					'RADICADO' => null,
					'FECHA_CREACION' => null,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  true,
					'MSGERROR' => 'Exception => '.$ex->getMessage()
			);
	  	}
		return $response_data;
	}
	
	function AddServicioComPublic($EntSecurity = array(), $EntServicioCom = array(), $EntInteresadoOfList = array() ,$EntRemitente = array())
	{
		$response_data = array ();
		$fecha_transaccion = date('Y-m-d G:i:s');
		$servicio_id = 0;
		$simad_util = new simad_util();
		//*******************************************************************************************************************
		$infoxml = file_get_contents("php://input");
		//*******************************************************************************************************************
		try{
			$filedir_target = sfConfig::get("sf_web_dir").DIRECTORY_SEPARATOR.'uploads'.DIRECTORY_SEPARATOR;
			//$logname = sfConfig::get("sf_log_dir").DIRECTORY_SEPARATOR.'request_timed.log';
			//***************************************************************************************************************
			$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
			if($usuario_ws['isError']){
				return responseErrorAttachment($usuario_ws['message']);
			}
			//***************************************************************************************************************
			$usuario_creador = $usuario_ws['object'];
			$wslog = WebserviceLogPeer::addLogWs("AddServicioComPublic",$infoxml,null,1,"Consumen Servicio web SGDEA","Ejecuta Exitoso",$usuario_creador->getUsuarioId());
			//***************************************************************************************************************
			$params = array();
			$periodo_id = isset($EntServicioCom['PERIODO_ID']) ? trim($EntServicioCom['PERIODO_ID']) : date("Y");
			$adju_b64 = isset($EntServicioCom['ARCHIVO_DIGIT']) ? trim($EntServicioCom['ARCHIVO_DIGIT']) : null;
			$filename_source = isset($EntServicioCom['ARCHIVO_NOMBRE']) ? (trim($EntServicioCom['ARCHIVO_NOMBRE'])) : null;
			$tiposervicio_text = isset($EntServicioCom['TIPO_SERVICIO']) ? trim($EntServicioCom['TIPO_SERVICIO']) : null;
			$uiduser_origen = isset($EntServicioCom['NUID_RADICA']) ? trim($EntServicioCom['NUID_RADICA']) : $usuario_creador->getCedula();
			$detalle = isset($EntServicioCom['DETALLE']) ? trim($EntServicioCom['DETALLE']) : null;
			$email_destino = isset($EntServicioCom['EMAIL_DESTINO']) ? trim($EntServicioCom['EMAIL_DESTINO']) : null;
			$radicado_com = isset($EntServicioCom['RADICADO_COM']) ? trim($EntServicioCom['RADICADO_COM']) : null;
			$radicado_origen = isset($EntServicioCom['RADICADO_ORIGEN']) ? trim($EntServicioCom['RADICADO_ORIGEN']) : null;
			$tipo_com = isset($EntServicioCom['TIPO_COM']) ? trim($EntServicioCom['TIPO_COM']) : null;
			$prioridadservicio_text = isset($EntServicioCom['PRIORIDAD_SERVICIO']) ? trim($EntServicioCom['PRIORIDAD_SERVICIO']) : null;
			$marconormativo_text = isset($EntServicioCom['MARCO_NORMATIVO']) ? trim($EntServicioCom['MARCO_NORMATIVO']) : null;
			$documentoorigen_text = isset($EntServicioCom['DOCUMENTO_ORIGEN']) ? trim($EntServicioCom['DOCUMENTO_ORIGEN']) : null;
			//***************************************************************************************************************
			$tiposervicio_id = TipoServicioPeer::getTipoServicioByName($tiposervicio_text);
			$prioridadservicio_id = PrioridadSolicitudServicioPeer::getPrioridadServicioByName($prioridadservicio_text);
			$marco_normativo = MarcoNormativoPeer::getMarcoNormativoByName($marconormativo_text);
			$marconormativo_id = $marco_normativo != null ? $marco_normativo->getPrimaryKey() : null;
			$procesodoc_origen = ProcesodocOrigenPeer::getProcesoDocOrigenByName($documentoorigen_text);
			$procesodocorigen_id = $procesodoc_origen != null ? $procesodoc_origen->getPrimaryKey() : null;
			$suborigen = $procesodoc_origen != null ?  $procesodoc_origen->getSuborigen() : 0;
			//***************************************************************************************************************
			if(!empty($uiduser_origen)){
				$cuser_origen = CargoUsuarioPeer::getCargoUsuarioByNuidUser($uiduser_origen,true);
			}else{
				$cuser_origen = CargoUsuarioPeer::getCargoUsuarioByNuidUser($usuario_creador->getCedula(),true);
			}			
			//***************************************************************************************************************
			$comlist_interesados = array();$laddnew_interesados = array();
			foreach ($EntInteresadoOfList as $info_list) {
				if(is_array($info_list)){
					if(simad_util::array_check($info_list,'PRIMER_NOMBRE') && simad_util::array_check($info_list,'PRIMER_APELLIDO') && simad_util::array_check($info_list,'NUMERO_IDENTIFICACION')){
						if(!trim($info_list['NUMERO_IDENTIFICACION'])){
							return responseErrorAttachment('El numero de identificación del interesado no es valido');
							exit;
						}
						//********************************************************************************************************
						$interesado_id = InteresadosPeer::existsIntByNameAndNuid($info_list['PRIMER_NOMBRE'],$info_list['PRIMER_APELLIDO'],$info_list['NUMERO_IDENTIFICACION']);
						if($interesado_id != null){
							$comlist_interesados[] = $interesado_id;
						}elseif(simad_util::array_check($info_list,'TIPO_IDENTIFICACION')){
							$tipouid_id = TipoIdentificacionPeer::getTipoIdentificacionPkBySigla(trim($info_list['TIPO_IDENTIFICACION']));
							if($tipouid_id == null){
								return responseErrorAttachment('El tipo de identificación del interesado no es un valor valido');
							}
							//********************************************************************************************************
							$info_list['TIPO_IDENTIFICACION'] = $tipouid_id;
							$optional_fileds = array('TIPO_GENERO' => true,'EMAIL' => true);
							$isValidIntInfo = InteresadosPeer::validateInfoNewInteresado($info_list,$optional_fileds);
							if($isValidIntInfo['IsValid'] == true){
								$laddnew_interesados[] = $info_list;
							}else{
								return responseErrorAttachment($isValidIntInfo['MsgError']);
							}
						}else{
							$info_list['TIPO_IDENTIFICACION'] = 5;
							$isValidIntInfo = InteresadosPeer::validateInfoNewInteresado($info_list);
							if($isValidIntInfo['IsValid'] == true){
								$laddnew_interesados[] = $info_list;
							}else{
								return responseErrorAttachment($isValidIntInfo['MsgError']);
							}
						}
					}else{
						return responseErrorAttachment('El nombre o numero de identificación del interesado no es valido');
					}
				}
			}
			//***************************************************************************************************************
			if(count($comlist_interesados) <= 0 && count($laddnew_interesados) <= 0){ return responseErrorAttachment('Debe enviar como minimo un interesado'); }
			//***************************************************************************************************************
			//$cuser_origen = $usuario_creador != null ? $usuario_creador : CargoUsuarioPeer::getCargoUsuarioByNuidUser($uiduser_origen,true);
			$regional_origen = isset($EntServicioCom['PUNTO_RADICACION']) ? RegionalPeer::getRegionalByName(trim($EntServicioCom['PUNTO_RADICACION'])) : null;
			//***************************************************************************************************************
			if($detalle == null){ return responseErrorAttachment('Debe enviar el detalle del servicio'); }
			if($adju_b64 == null){ return responseErrorAttachment('Debe enviar el documento digital del servicio'); }
			if($tiposervicio_id == null){ return responseErrorAttachment('El tipo de servicio no se encontro en el SGDEA'); }
			if($prioridadservicio_id == null){ return responseErrorAttachment('La prioridad del servicio no se encontro en el SGDEA'); }
			if($filename_source == null ){ return responseErrorAttachment('El nombre del archivo es un campo obligatorio'); }
			//***************************************************************************************************************
			$file_vars = pathinfo($filedir_target.$filename_source);
			$filename_source = $simad_util->clean_name_file($file_vars);
			//***************************************************************************************************************
			$fullpath = $filedir_target.$filename_source;
			$isCreate = simad_util::getConvertB64ToFile($adju_b64,$fullpath);
			//***************************************************************************************************************
			if(!$isCreate){ return responseErrorAttachment('Error interno del servidor al crear el archivo'); }
			//***************************************************************************************************************
			$mime_trust = array('application/pdf', 'application/x-pdf', 'application/x-bzpdf', 'application/x-gzpdf');
			$file_valid = simad_util::CheckIsValidFormatFile($fullpath,$mime_trust);
			if(!$file_valid){ return responseErrorAttachment('El formato del archivo no esta permitido'); }
			//***************************************************************************************************************
			$info_file = new SplFileInfo($fullpath);
			//$mimetypes = array("pdf","doc", "docx");
			$mimetypes = array("pdf");
			$extension  = strtolower($info_file->getExtension());
			if(!in_array($extension,$mimetypes)){
				unlink($fullpath);
				return responseErrorAttachment('El formato '.$extension.' del archivo no es valido'); 
			}
			//***************************************************************************************************************
			if($regional_origen == null){
				$regional_origen = RegionalPeer::retrieveByPk($usuario_creador->getRegionalId());
			}
			//***************************************************************************************************************
			$addRemitente = false;$directorio_externo = null;
			if(count($EntRemitente)){
				$nuid_remitente = isset($EntComEnviada['NUID']) ? trim($EntComEnviada['NUID']) : null;
				if($nuid_remitente != null){
					$directorio_externo = DirectorioExternoPeer::existsDirectorioExterno($EntRemitente);
				}else{
					$addRemitente = false;
				}
			}
			//***************************************************************************************************************
			$directorioexterno_id = !empty($directorio_externo) ? $directorio_externo->getPrimaryKey() : null;
			//***************************************************************************************************************
			$params['regional_id'] = $regional_origen->getPrimaryKey();
			$params['usuario_id'] = $cuser_origen->getUsuarioId();						
			$params['periodo_id'] = $periodo_id;
			$params['detalle'] = $detalle;
			$params['folios'] = isset($EntServicioCom['FOLIOS']) ? trim($EntServicioCom['FOLIOS']) : 0;
			$params['archivo_digit'] = $adju_b64;
			$params['tiposervicio_id'] = $tiposervicio_id;
			$params['marconormativo_id'] = $marconormativo_id;
			$params['procesodocorigen_id'] = $procesodocorigen_id;
			$params['prioridadsolicitudservicio_id'] = $prioridadservicio_id != null ? $prioridadservicio_id : 1;
			$params['numero_resolucion'] = isset($EntServicioCom['NUMERO_RESOLUCION']) ? trim($EntServicioCom['NUMERO_RESOLUCION']) : null;
			$params['directorioexterno_id'] = $directorioexterno_id;
			$params['email_destino'] = $email_destino;
			$params['radicado_origen'] = $radicado_origen;
			$params['coll_interesados'] = null;
			$params['suborigen'] = $suborigen;
			$params['full_path'] = $fullpath;
			//***************************************************************************************************************
			$pkconsecutivo_id = null;
			if($tipo_com == 1){
				$com_enviada = ComEnviadaPeer::getComObjectByRadicado($radicado_com,$periodo_id);
				$pkconsecutivo_id = $com_enviada != null ? $com_enviada->getPrimaryKey() : null;
			}elseif($tipo_com == 2){
				$com_recibida = ComRecibidaPeer::getComObjectByRadicado($radicado_com,$periodo_id);
				$pkconsecutivo_id = $com_recibida != null ? $com_recibida->getPrimaryKey() : null;
			}elseif($tipo_com == 3){
				$com_interna = ComInternaPeer::getComObjectByRadicado($radicado_com,$periodo_id);
				$pkconsecutivo_id = $com_interna != null ? $com_interna->getPrimaryKey() : null;
			}
			//***************************************************************************************************************
			$params['pkconsecutivo_id'] = $pkconsecutivo_id;
			//***************************************************************************************************************
			if (isset($EntServicioCom['FECHA_RESOLUCION'])){
				$fecha_resolucion = trim($EntServicioCom['FECHA_RESOLUCION']);
				try{
					if (strpos($fecha_resolucion,"/") !== false){
						$date = str_replace('/', '-', $fecha_resolucion); 
						$fecha_resolucion = date('Y-m-d', strtotime($date));
					}
					
					$date = new DateTime($fecha_resolucion);
					$params['fecha_resolucion'] = $date->format('Y-m-d');
				}catch (Exception $ex){
					$params['fecha_resolucion'] = null;
					return responseErrorAttachment('El formato de la fecha resolución no es valido '.$ex->getMessage());
				}
			}
			//***************************************************************************************************************
			$response = ServicioPeer::createServicioByCom($params,$pkconsecutivo_id,null);
			//***************************************************************************************************************
			if($response['isError'] == true){
				return responseErrorAttachment(!empty($response['message']) ? $response['message'] : 'Error interno del servidor del SGDEA');
			}
			//***************************************************************************************************************
			//$servicio_com = new Servicio();
			$servicio_com = (object)$response['object'];
			$servicio_id = $servicio_com->getPrimaryKey();
			//***************************************************************************************************************
			foreach ($laddnew_interesados as $newitem) {
				$newitem['USUARIO_ID'] = $servicio_com->getUsuarioId();
				$interesado_id = InteresadosPeer::addNewInteresado($newitem);
				if($interesado_id == null){
					$servicio_com->delete();
					return responseErrorAttachment('Ocurrio un error al crear el interesado en el SGDEA'); 
				}else{
					$comlist_interesados[] = $interesado_id;
				}
			}
			//***************************************************************************************************************
			foreach ($comlist_interesados as $interesado_item) {
				ServicioInteresadosPeer::addNewInteresadoByComId($servicio_com->getPrimaryKey(),$interesado_item);
			}
			//***************************************************************************************************************
			$response_anexo = $servicio_com->addNewAnexo($fullpath);
			if($response_anexo == null){
				ServicioPeer::deleteCascada($servicio_com->getPrimaryKey());
				return responseErrorAttachment('Ocurrio un error al adjuntar el archivo, el servicio no se radico');
			}
			//***************************************************************************************************************
			if($wslog != null){
				$wslog->setTipoOperacion("Consumen Servicio web SGDEA => ".$servicio_com->getRadicado());
				$wslog->setMensaje("Ejecuta Exitoso Genera Radicado".(empty($msgintegracion) ? "" : ", ".$msgintegracion));
				$wslog->save();
			}
			//***************************************************************************************************************
			$msgintegracion = "";
			if($servicio_com->getTipoServicio()->getInitIntegracion()){
				try {
					$coll_interesados = ServicioPeer::getListIntersadosByComId($servicio_com->getPrimaryKey());
					//*******************************************************************************************************
					$simadSoap = new WsSimadUariv();
					$response_acto = $simadSoap->loadWsRadActoAdmByNotCom($params,$coll_interesados);
					$msgintegracion = $response_acto['message'];
				} catch (\Throwable $th) {
					$msgintegracion = $th->getMessage();
				}
			}
			//***************************************************************************************************************
			if($wslog != null){
				$wslog->setTipoOperacion("Consumen Servicio web SGDEA => ".$servicio_com->getRadicado());
				$wslog->setMensaje("Ejecuta Exitoso Genera Radicado".(empty($msgintegracion) ? "" : ", ".$msgintegracion));
				$wslog->save();
			}
			//***************************************************************************************************************
			$response_data = array ( 'CONSECUTIVO_ID' => $servicio_com->getPrimaryKey(),
					'RADICADO' => $servicio_com->getRadicado(),
					'FECHA_CREACION' => $servicio_com->getFechaCreacion(),
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  false,
					'MSG_INFO' => "Servicio radicado exitosamente".(empty($msgintegracion) ? "" : ", ".$msgintegracion)
			);
		}catch(PropelException $ex){
			$response_data = array ( 'CONSECUTIVO_ID' => null,
					'RADICADO' => null,
					'FECHA_CREACION' => null,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  true,
					'MSG_INFO' => 'El servicio no se radico, SoapFault => '.$ex->getMessage()
			);
		}catch(SoapFault $ex){
			ServicioPeer::deleteCascada($servicio_id);
			//***************************************************************************************************************
			$response_data = array ( 'CONSECUTIVO_ID' => null,
					'RADICADO' => null,
					'FECHA_CREACION' => null,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  true,
					'MSG_INFO' => 'El servicio no se radico, SoapFault => '.$ex->getMessage()
			);
		}catch(Exception $ex){
			ServicioPeer::deleteCascada($servicio_id);
			//***************************************************************************************************************
			$response_data = array ( 'CONSECUTIVO_ID' => null,
					'RADICADO' => null,
					'FECHA_CREACION' => null,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  true,
					'MSG_INFO' => 'El servicio no se radico, Exception => '.$ex->getMessage()
			);
		}
		//*******************************************************************************************************************
		return $response_data;
	}

	function AddAttachDocumento($EntSecurity = array(), $EntAttachDocument = array())
	{
		$response_data = array ();
		$fecha_transaccion = date('Y-m-d G:i:s');
		$info_response = "";$isErrorWs = false;
		//*******************************************************************************************************************
		//file_put_contents(sfConfig::get("sf_log_dir").DIRECTORY_SEPARATOR."AddRadicadoSalidaOferta.log", file_get_contents("php://input"));
		$infoxml = file_get_contents("php://input");
		$simad_util = new simad_util();
		//*******************************************************************************************************************
		try{
			//$filedir_target = sfConfig::get("sf_web_dir").DIRECTORY_SEPARATOR.'uploads'.DIRECTORY_SEPARATOR;
			$dir_raiz = simad_util::NormalizePath(ParametroPeer::retrieveByPk(29)->getValortexto().'uploads');
			$filedir_target = simad_util::createPath($dir_raiz.DIRECTORY_SEPARATOR.date("Ymd")).DIRECTORY_SEPARATOR;
			//***************************************************************************************************************
			$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
			if($usuario_ws['isError']){
				return responseErrorAttachment($usuario_ws['message']);
			}
			//***************************************************************************************************************
			$usuario_creador = $usuario_ws['object'];
			$wslog = WebserviceLogPeer::addLogWs("AddAttachDocumento",$infoxml,null,1,"Consumen Servicio web SGDEA","Ejecuta Exitoso",$usuario_creador->getPrimaryKey());
			//***************************************************************************************************************
			$params = array();			
			
			$adju_b64 = isset($EntAttachDocument['ARCHIVO_DATA']) ? trim($EntAttachDocument['ARCHIVO_DATA']) : null;
			$filename = isset($EntAttachDocument['ARCHIVO_NOMBRE']) ? utf8_encode(trim($EntAttachDocument['ARCHIVO_NOMBRE'])) : null;

			$radicado_com = isset($EntAttachDocument['RADICADO_COMUNICACION']) ? trim($EntAttachDocument['RADICADO_COMUNICACION']) : null;
			$consecutivo_com = isset($EntAttachDocument['CONSECUTIVO_COMUNICACION']) ? trim($EntAttachDocument['CONSECUTIVO_COMUNICACION']) : null;
			$tipo_consecutivo = isset($EntAttachDocument['TIPO_CONSECUTIVO']) ? trim($EntAttachDocument['TIPO_CONSECUTIVO']) : null;
			$notifica_radicado = isset($EntAttachDocument['NOTIFICA_RADICADO']) ? trim($EntAttachDocument['NOTIFICA_RADICADO']) : false;
			//***************************************************************************************************************
			$file_parts = pathinfo($filename);
			if(empty($file_parts['extension'])){ return responseErrorAttachment('El nombre del archivo no es valido'); }
			//***************************************************************************************************************
			if(empty($radicado_com) && empty($consecutivo_com)){ return responseErrorAttachment('El numero de radicado o el consucutivo de la comunicación es obligatorio'); }
			if(empty($filename)){ return responseErrorAttachment('El nombre del archivo es un campo obligatorio'); }
			if(empty($adju_b64)){ return responseErrorAttachment('El documento adjunto no fue enviado'); }
			if(empty($tipo_consecutivo)){ return responseErrorAttachment('El tipo de consecutivo es obligatorio'); }
			//***************************************************************************************************************
			$file_vars = pathinfo($filedir_target.$filename);
			$filename_source = $simad_util->clean_name_file($file_vars);
			$fullpath = $filedir_target.uniqid()."_".$filename_source;
			$isCreate = simad_util::getConvertB64ToFile($adju_b64,$fullpath);
			//***************************************************************************************************************
			if(!$isCreate){ return responseErrorAttachment('Error interno del servidor o el archivo no es valido, no se realizó la acción solicitada'); }
			//***************************************************************************************************************
			$info_file = new SplFileInfo($fullpath);
			//$mimetypes = array("pdf","doc", "docx");
			$mimetypes = array("exe", "sys", "ini", "com", "dll", "jar", "bat", "cmd", "vbs", "tmp", "php", "py", "inf", "lnk", "csf", "msi", "msp", "gadget", "ps1", "ps1xml", "ps2", "ps2xml", "psc1", "psc2");
			$extension  = strtolower($info_file->getExtension());
			if(in_array($extension,$mimetypes)){
				unlink($fullpath);
				return responseErrorAttachment('El tipo de archivo '.$extension.' no esta permitido'); 
			}
			//***************************************************************************************************************
			$params['archivo_digit'] = $adju_b64;
			//$params['filename'] = $filename;
			$params['filename'] = $filename_source;
			$params['fullpath'] = $info_file->getRealPath();
			$params['radicado_com'] = $radicado_com;
			$params['consecutivo_com'] = $consecutivo_com;
			$list_files = array($params['fullpath']);
			//***************************************************************************************************************
			if($wslog != null){
				$wslog->setTipoOperacion("Consumen Servicio web SGDEA => ".$radicado_com);
				$wslog->setMensaje("Ejecuta Exitoso Adjunta Documentos");
				$wslog->save();
			}
			//***************************************************************************************************************
			$isErrorCom = false;$consecutivo_id = 0;$radicado="";
			switch ($tipo_consecutivo) {
				case 1://enviadas
					$com_enviada =  ComEnviadaPeer::getObjectComByRadicadoOrId($radicado_com,$consecutivo_com);
					if($com_enviada == null){ $isErrorCom = true; break; }
					//*******************************************************************************************************
					if($notifica_radicado && ($com_enviada->getServicioId())){
						foreach($list_files as $ifile){
							$response_attach = $com_enviada->attachDocumentToServiceCom($ifile,$usuario_creador->getPrimaryKey());
						}
					}elseif(($com_enviada->getTipoEnvio() == 4) && ($com_enviada->getServicioId())){
						foreach($list_files as $ifile){
							$response_attach = $com_enviada->attachDocumentToServiceCom($ifile,$usuario_creador->getPrimaryKey());
						}
					}else{
						$response_attach = $com_enviada->addNewAttachDocument($list_files);
					}
					//*******************************************************************************************************
					$radicado = $com_enviada->getRadicado();
					$consecutivo_id = $com_enviada->getPrimaryKey();
					break;
				case 2://recibidas
					$com_recibida =  ComRecibidaPeer::getObjectComByRadicadoOrId($radicado_com,$consecutivo_com);
					if($com_recibida == null){ $isErrorCom = true; break; }
					$response_attach = $com_recibida->addNewAttachDocument($list_files);
					$radicado = $com_recibida->getRadicado();
					$consecutivo_id = $com_recibida->getPrimaryKey();
					break;
				case 3://interna
					$com_interna =  ComInternaPeer::getObjectComByRadicadoOrId($radicado_com,$consecutivo_com);
					if($com_interna == null){ $isErrorCom = true; break; }
					$response_attach = $com_interna->addNewAttachDocument($list_files);
					$radicado = $com_interna->getRadicado();
					$consecutivo_id = $com_interna->getPrimaryKey();
					break;
				default:
					$isErrorCom = true;
					break;
			}
			//***************************************************************************************************************
			if($isErrorCom){ return responseErrorAttachment('El radicado no se encontro en el sgdea(radicado => '.$radicado_com.'; consecutivo_com => '.$consecutivo_com.'), verifique los datos'); }
			//***************************************************************************************************************
			if($response_attach['isError'] == true){
				$isErrorWs = true;
				foreach($response_attach['list_state'] as $breponse){
					if($breponse['filename'] == $filename){
						$info_response = $breponse['info'];
						break;
					}
				}
			}else{
				$info_response = 'El archivo se adjunto correctamente a la comunicación con radicado '.$radicado_com;
			}
			//***************************************************************************************************************
			$response_data = array ( 'CONSECUTIVO_ID' => $consecutivo_id,
					'RADICADO' => $radicado,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  $isErrorWs,
					'MSG_INFO' => $info_response
			);
		}catch(SoapFault $ex){
			$response_data = array ( 'CONSECUTIVO_ID' => null,
					'RADICADO' => null,
					'FECHA_CREACION' => null,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  true,
					'MSG_INFO' => $ex->getMessage()
			);
		}catch(PropelException $ex){
			$response_data = array ( 'CONSECUTIVO_ID' => null,
					'RADICADO' => null,
					'FECHA_CREACION' => null,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  true,
					'MSG_INFO' => $ex->getMessage()
			);
		}catch(Exception $ex){
			//$logname = sfConfig::get("sf_log_dir").DIRECTORY_SEPARATOR.'AddAttachRadicadoSalida.log';
			//simad_util::writetolog($logname,$ex->getMessage());
			$response_data = array ( 'CONSECUTIVO_ID' => null,
					'RADICADO' => null,
					'FECHA_CREACION' => null,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  true,
					'MSG_INFO' => $ex->getMessage()
			);
	  	}
		return $response_data;
	}

	function ListAttachDocumento($EntSecurity = array(), $EntViewAttachDoc = array())
	{
		$response_data = array ();
		$fecha_transaccion = date('Y-m-d G:i:s');
		$info_response = "";$isErrorWs = false;
		//*******************************************************************************************************************
		//file_put_contents(sfConfig::get("sf_log_dir").DIRECTORY_SEPARATOR."AddRadicadoSalidaOferta.log", file_get_contents("php://input"));
		$infoxml = file_get_contents("php://input");
		//*******************************************************************************************************************
		try{
			$target_tmp = sfConfig::get("sf_web_dir").DIRECTORY_SEPARATOR.'tmp'.DIRECTORY_SEPARATOR;
			//***************************************************************************************************************
			$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
			if($usuario_ws['isError']){
				return responseErrorAttachment($usuario_ws['message']);
			}
			//***************************************************************************************************************
			$usuario_creador = $usuario_ws['object'];
			$wslog = WebserviceLogPeer::addLogWs("ListAttachDocumento",$infoxml,null,1,"Consumen Servicio web SGDEA","Ejecuta Exitoso",$usuario_creador->getPrimaryKey());
			//***************************************************************************************************************
			$list_attach =  array();
			$radicado_com = isset($EntViewAttachDoc['RADICADO_COMUNICACION']) ? trim($EntViewAttachDoc['RADICADO_COMUNICACION']) : null;
			$tipo_consecutivo = isset($EntViewAttachDoc['TIPO_CONSECUTIVO']) ? trim($EntViewAttachDoc['TIPO_CONSECUTIVO']) : null;
			//***************************************************************************************************************
			if(empty($radicado_com)){ return responseErrorAttachment('El numero de radicado de la comunicación es obligatorio'); }
			if(empty($tipo_consecutivo)){ return responseErrorAttachment('El tipo de consecutivo es obligatorio'); }
			//***************************************************************************************************************
			$isErrorCom = false;$consecutivo_id = 0;$radicado="";
			switch ($tipo_consecutivo) 
			{
				case 1://enviadas
					$com_enviada =  ComEnviadaPeer::getObjectComByRadicadoOrId($radicado_com);
					if($com_enviada == null){ $isErrorCom = true; break; }
					//*******************************************************************************************************
					$list_attach = $com_enviada->getListDigitDocument();
					break;
				case 2://recibidas
					$com_recibida =  ComRecibidaPeer::getObjectComByRadicadoOrId($radicado_com);
					if($com_recibida == null){ $isErrorCom = true; break; }
					//*******************************************************************************************************
					$list_attach = $com_recibida->getListDigitDocument();
					break;
				case 3://interna
					$com_interna =  ComInternaPeer::getObjectComByRadicadoOrId($radicado_com);
					if($com_interna == null){ $isErrorCom = true; break; }
					//*******************************************************************************************************
					$list_attach = $com_interna->getListDigitDocument();
					break;
				default:
					$isErrorCom = true;
					break;
			}
			//***************************************************************************************************************
			if($isErrorCom){ return responseErrorAttachment('No se encontro en el SGDEA el radicado '.$radicado_com.', verifique los datos'); }
			//***************************************************************************************************************
			if($wslog != null){
				$wslog->setTipoOperacion("Consumen Servicio web SGDEA => ".$radicado_com);
				$wslog->setMensaje("Ejecuta Exitoso Genera Listado Adjuntos");
				$wslog->save();
			}
			//***************************************************************************************************************
			if(count($list_attach)){
				$response_data = array ('LIST_DOCUMENTOS' => $list_attach,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  false,
					'MSG_INFO' => 'Lista de documentos adjuntos al radicado'
				);
			}else{
				$response_data = array ('LIST_DOCUMENTOS' => null,
					'URL_ACCESO' => null,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  false,
					'MSG_INFO' => 'El radicado no contiene documentos adjuntos'
				);
			}
			//***************************************************************************************************************
		}catch(PropelException $ex){
			$response_data = array ('LIST_DOCUMENTOS' => null,
				'URL_ACCESO' => null,
				'FECHA_TRANSACCION' => $fecha_transaccion,
				'ISERROR' =>  true,
				'MSG_INFO' => $ex->getMessage()
			);
		}catch(SoapFault $ex){
			$response_data = array ('LIST_DOCUMENTOS' => null,
				'URL_ACCESO' => null,
				'FECHA_TRANSACCION' => $fecha_transaccion,
				'ISERROR' =>  true,
				'MSG_INFO' => $ex->getMessage()
			);
		}catch(Exception $ex){
			$response_data = array ('LIST_DOCUMENTOS' => null,
				'URL_ACCESO' => null,
				'FECHA_TRANSACCION' => $fecha_transaccion,
				'ISERROR' =>  true,
				'MSG_INFO' => $ex->getMessage()
			);
	  	}
		return $response_data;
	}
	
	function GetMetadataInfoCom($EntSecurity = array(), $ComSearchInfo = array())
	{
		$response_data = array ();
		$fecha_transaccion = date('Y-m-d G:i:s');
		//*******************************************************************************************************************
		//file_put_contents(sfConfig::get("sf_log_dir").DIRECTORY_SEPARATOR."AddRadicadoSalidaOferta.log", file_get_contents("php://input"));
		$infoxml = file_get_contents("php://input");
		//*******************************************************************************************************************
		try{
			$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
			if($usuario_ws['isError']){
				return array ('FECHA_TRANSACCION' => $fecha_transaccion,'ISERROR' =>  false,'MSG_INFO' => $usuario_ws['message']);
			}
			//***************************************************************************************************************
			$com_infodata =  array();
			$cons_entrada = isset($ComSearchInfo['CONSECUTIVO_ENTRADA']) ? trim($ComSearchInfo['CONSECUTIVO_ENTRADA']) : null;
			$cons_salida = isset($ComSearchInfo['CONSECUTIVO_SALIDA']) ? trim($ComSearchInfo['CONSECUTIVO_SALIDA']) : null;
			$radicado_entrada = isset($ComSearchInfo['RADICADO_ENTRADA']) ? trim($ComSearchInfo['RADICADO_ENTRADA']) : null;
			$radicado_salida = isset($ComSearchInfo['RADICADO_SALIDA']) ? trim($ComSearchInfo['RADICADO_SALIDA']) : null;
			$radicado_com = $radicado_entrada != null ? $radicado_entrada : $radicado_salida;
			//***************************************************************************************************************
			$usuario_creador = $usuario_ws['object'];
			$wslog = WebserviceLogPeer::addLogWs("GetMetadataInfoCom",$infoxml,null,1,"Consumen Servicio web SGDEA => ".($radicado_com),"Ejecuta Exitoso => ".($radicado_com),$usuario_creador->getPrimaryKey());
			//***************************************************************************************************************
			if(empty($cons_entrada) && empty($cons_salida)){ return responseErrorAttachment('Debe enviar por lo menos un consecutivo para consultar'); }
			//***************************************************************************************************************
			$isErrorCom = false;$radicado_com = "";
			if(!empty($cons_entrada)){
				$com_recibida =  ComRecibidaPeer::getObjectComByRadAndPkId($radicado_entrada,$cons_entrada);
				if($com_recibida == null){ $isErrorCom = true; }				
				else{ $com_infodata = $com_recibida->getBasicInfoMetadata(); }
			}else{
				$com_enviada =  ComEnviadaPeer::getObjectComByRadicadoOrId($radicado_salida,$cons_salida);
				if($com_enviada == null){ $isErrorCom = true; }
				else{ $com_infodata = $com_enviada->getBasicInfoMetadata(); }
			}
			//***************************************************************************************************************
			if($isErrorCom){ return responseErrorAttachment('No se encontro en el SGDEA el radicado '.$radicado_com.', verifique los datos'); }
			//***************************************************************************************************************
			if(count($com_infodata)){
				$response_data = array_merge($com_infodata,array (
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  false,
					'MSG_INFO' => 'Informacion del radicado'
				));
			}else{
				$response_data = array (
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  false,
					'MSG_INFO' => 'El radicado no contiene documentos adjuntos'
				);
			}
			//***************************************************************************************************************
			
		}catch(SoapFault $ex){
			$response_data = array (
				'FECHA_TRANSACCION' => $fecha_transaccion,
				'ISERROR' =>  true,
				'MSG_INFO' => $ex->getMessage()
			);
		}catch(Exception $ex){
			$response_data = array (
				'FECHA_TRANSACCION' => $fecha_transaccion,
				'ISERROR' =>  true,
				'MSG_INFO' => $ex->getMessage()
			);
	  	}
		return $response_data;
	}

	function AddNewDocumentoExp($EntSecurity = array(), $ArcAddDocumento = array())
	{
		$response_data = array ();
		$fecha_transaccion = date('Y-m-d G:i:s');
		$simad_util = new simad_util();
		//*******************************************************************************************************************
		$infoxml = file_get_contents("php://input");
		//*******************************************************************************************************************
		try
		{
			$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
			if($usuario_ws['isError'])
			{
				return array 
				(
					'CONSECUTIVO_ID' => null,
					'NUMERO_EXPEDIENTE' => null,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  false,
					'MSG_INFO' => $usuario_ws['message']
				);
			}
			//***************************************************************************************************************
			// CASO EXITOSO
				$numero_expediente = isset($ArcAddDocumento['NUMERO_EXPEDIENTE']) ? trim($ArcAddDocumento['NUMERO_EXPEDIENTE']) : null;
				$verif_udocumental = isset($ArcAddDocumento['VERIF_UDOCUMENTAL']) ? trim($ArcAddDocumento['VERIF_UDOCUMENTAL']) : null;
				$tipodoc_codigo = isset($ArcAddDocumento['TIPODOC_CODIGO']) ? trim($ArcAddDocumento['TIPODOC_CODIGO']) : null;
				$estado_documento = isset($ArcAddDocumento['ESTADO_DOCUMENTO']) ? trim($ArcAddDocumento['ESTADO_DOCUMENTO']) : null;
				$nuip_creador = isset($ArcAddDocumento['NUIP_CREADOR']) ? trim($ArcAddDocumento['NUIP_CREADOR']) : null;
				$firma_estampa = isset($ArcAddDocumento['FIRMA_ESTAMPA']) ? trim($ArcAddDocumento['FIRMA_ESTAMPA']) : null;
				$soporte_documento = isset($ArcAddDocumento['SOPORTE_DOCUMENTO']) ? trim($ArcAddDocumento['SOPORTE_DOCUMENTO']) : null;
				$origen_documento = isset($ArcAddDocumento['ORIGEN_DOCUMENTO']) ? trim($ArcAddDocumento['ORIGEN_DOCUMENTO']) : null;
				$descripcion = isset($ArcAddDocumento['DESCRIPCION']) ? trim($ArcAddDocumento['DESCRIPCION']) : null;
				$archivo_anexo = isset($ArcAddDocumento['ARCHIVO_ANEXO']) ? trim($ArcAddDocumento['ARCHIVO_ANEXO']) : null;
				$archivo_nombre = isset($ArcAddDocumento['ARCHIVO_NOMBRE']) ? trim($ArcAddDocumento['ARCHIVO_NOMBRE']) : null;
				$folios = isset($ArcAddDocumento['FOLIOS']) ? trim($ArcAddDocumento['FOLIOS']) : null;
				$fecha_documento = isset($ArcAddDocumento['FECHA_DOCUMENTO']) ? trim($ArcAddDocumento['FECHA_DOCUMENTO']) : null;
				$orden_contenido = isset($ArcAddDocumento['ORDEN_CONTENIDO']) ? trim($ArcAddDocumento['ORDEN_CONTENIDO']) : null;
				// ***************************************************************************************
				$usuario_ws = $usuario_ws['object'];
				$wslog = WebserviceLogPeer::addLogWs("AddNewDocumentoExp",$infoxml,null,1,"Consumen Servicio web SGDEA => ".($numero_expediente),"Ejecuta Exitoso => ".($numero_expediente),$usuario_ws->getPrimaryKey());
				//******************************************************************
				if(empty($descripcion))
				{
					return responseErrorDataExp('El campo Descripcion es obligatorio');
				}
				if(empty($folios))
				{
					return responseErrorDataExp('El campo Folios es obligatorio');
				}
				if(empty($fecha_documento))
				{
					return responseErrorDataExp('El campo Fecha Documento es obligatorio');
				}
				if(empty($orden_contenido))
				{
					return responseErrorDataExp('El campo Orden Contenido es obligatorio');
				}
				$ilunidad_documental = UnidadDocumentalPeer::getUnidadDocumentalByCodigo($numero_expediente);  // codigo de barras
				if(count($ilunidad_documental) > 1)
				{
					return responseErrorDataExp('Existe mas de un registro con el mismo numero de expediente');
				}
				else if(!array_key_exists(0, $ilunidad_documental))
				{
					return responseErrorDataExp('El numero de expediente no es valido');
				}

				$unidad_documental = $ilunidad_documental[0];
				$unidad_documental_pk = $unidad_documental->getPrimaryKey();
				$subSerieId = $unidad_documental->getSubserieId();
				$is_verif_udocumental = VerificacionContUnidadDocPeer::getVerificacionContUnidadDocumentalDescripcion($verif_udocumental);
				$verificacion_doc = 1;
				if(!empty($is_verif_udocumental))
				{
					$verificacion_doc = $is_verif_udocumental->getPrimaryKey();	
				}
				$obj_tipodoc_codigo = TipoDocumentalPeer::getTipoDocumentalCodigo($tipodoc_codigo, $subSerieId);
				if(empty($obj_tipodoc_codigo))
				{
					return responseErrorDataExp('El codigo del tipo documental no es valido');
				}
				$tipo_doc_id = $obj_tipodoc_codigo->getPrimaryKey();
				$is_estado_documento = EstadoContenidoUnidadDocumentalPeer::getEstadoContenidoUnidadDocumentalDescripcion($estado_documento);
				$estado_doc = 1;
				if(!empty($is_estado_documento))
				{
					$estado_doc = $is_estado_documento->getPrimaryKey();
				}
				$cuser_creador = CargoUsuarioPeer::getCargoUsuarioByNuidUser($nuip_creador, true);
				if(empty($cuser_creador))
				{
					return responseErrorDataExp('El Usuario no existe en el SGDEA');
				}

				$usuario_id = $cuser_creador->getUsuarioId();
				$is_firma_estampa = TipoFirmaDigitalPeer::getTipoFirmaDigitalDescripcion($firma_estampa);
				$tipofirmadigital_id = null;
				if(!empty($is_firma_estampa))
				{
					$tipofirmadigital_id = $is_firma_estampa->getPrimaryKey();
				}
				$is_soporte_documento = SoporteUnidadDocumentalPeer::getSoporteUnidadDocDesp($soporte_documento);
				$soporte_documental = 1;
				if(!empty($is_soporte_documento))
				{
					$soporte_documental = $is_soporte_documento->getPrimaryKey();
				}
				$is_origen_documento = OrigenDocumentoPeer::getOrigenDocumentoDescripcion($origen_documento);
				$origen_documental = 1;
				if(empty($is_origen_documento))
				{
					$origen_documental = $is_origen_documento->getPrimaryKey();
				}

				$params = array();
				$params['tipodoc_codigo'] = $tipodoc_codigo;
				$params['estado_documento'] = $estado_documento;
				$params['firma_estampa'] = $firma_estampa;
				$params['soporte_documento'] = $soporte_documento;
				$params['origen_documento'] = $origen_documento;
				$params['descripcion'] = $descripcion;
				$params['archivo_anexo'] = $archivo_anexo; // ????
				$params['folios'] = $folios;
				$params['fecha_documento'] = $fecha_documento;
				$params['orden_contenido'] = $orden_contenido;
				$params['verificacion_doc'] = $verificacion_doc;
				$params['estado_doc'] = $estado_doc;
				$params['tipofirmadigital_id'] = $tipofirmadigital_id;
				$params['soporte_documental'] = $soporte_documental;
				$params['tipo_doc_id'] = $tipo_doc_id;
				$params['unidad_documental_pk'] = $unidad_documental_pk;
				$params['usuario_id'] = $usuario_id;
				//****************************************************************************************************
				//MANEJO DE ARCHIVOS UPLOADS
				//****************************************************************************************************
				$dir_raiz = simad_util::NormalizePath(ParametroPeer::retrieveByPk(17)->getValortexto().'uploads'); // ubicacion en el disco duro donde va a guardar el archivo
				$filedir_target = simad_util::createPath($dir_raiz . DIRECTORY_SEPARATOR . date("Ymd")) . DIRECTORY_SEPARATOR;
				$file_vars = pathinfo($filedir_target . $archivo_nombre);
				$filename_source = uniqid() . "_" . $simad_util->clean_name_file($file_vars);
				$fullpath = $filedir_target. $filename_source;
				$isCreate = simad_util::getConvertB64ToFile($archivo_anexo, $fullpath);  
				//***************************************************************************************************************
				if(!$isCreate) 
				{ 
					return responseErrorDataExp('Error interno del servidor o el archivo no es valido, no se realizó la acción solicitada'); 
				}
				//***************************************************************************************************************
				// valida que le archivo sea de la extension permitida solamente
				$info_file = new SplFileInfo($fullpath);
				$mimetypes = array("exe", "sys", "ini", "com", "dll", "jar", "bat", "cmd", "vbs", "tmp", "php", "py", "inf", "lnk", "csf", "msi", "msp", "gadget", "ps1", "ps1xml", "ps2", "ps2xml", "psc1", "psc2");
				$extension  = strtolower($info_file->getExtension());
				if(in_array($extension, $mimetypes))
				{
					unlink($fullpath);
					return responseErrorDataExp('El tipo de archivo ' . $extension . ' no esta permitido'); 
				}
				//***************************************************************************************************************
				$folder_list = $unidad_documental->getBaseUrlAttachment($cuser_creador->getUsuarioId(), true);
				$path_absolute = $folder_list['absolute_path'];
				$path_relative = $folder_list['basic_path'];
				//RUTA DE OBJETIVO**********************
				$directorio_entidad = $folder_list['full_path']; // TARGET - FULL PATH
				$file_target = ($directorio_entidad) . DIRECTORY_SEPARATOR . $filename_source;
				//********************************************************************************
				$szfile = 0;
				$exfile = null;
				if(@copy($fullpath, $file_target))
				{
					$szfile = filesize($file_target);
					$exfile = pathinfo($fullpath, PATHINFO_EXTENSION);
					unlink($fullpath);
				}
				else
				{
					return responseErrorDataExp('Error interno del servidor, relacionado con el archivo adjunto'); 
				}
				$params['path_absolute'] = $path_absolute;
				$params['path_relative'] = $path_relative;
				$params['size_file'] = $szfile;
				$params['format_file'] = strtoupper($exfile);
				$params['archivo_nombre'] = $filename_source;
				//************************************************************************* */
				$contenido_unidad_documental_added = ContenidoUnidadDocumentalPeer::addContenidoUnidadDocumental($params);
				//************************************************************************* */
				if(empty($contenido_unidad_documental_added))
				{
					return responseErrorDataExp('No se puedo guardar, ocurrio un error interno en el servidor.');
				}			
			$response_data = array 
			( 
				'CONSECUTIVO_ID' => null,
				'NUMERO_EXPEDIENTE' => null,
				'FECHA_TRANSACCION' => $fecha_transaccion,
				'ISERROR' =>  False,
				'MSG_INFO' => 'Expediente creado exitosamente'
			);
		}
		catch(SoapFault $ex)
		{
			$response_data = array (
				'CONSECUTIVO_ID' => null,
				'NUMERO_EXPEDIENTE' => null,
				'FECHA_TRANSACCION' => null,
				'ISERROR' =>  true,
				'MSG_INFO' => $ex->getMessage()
			);
	  	}
		catch(Exception $ex)
		{
			$response_data = array (
				'CONSECUTIVO_ID' => null,
				'NUMERO_EXPEDIENTE' => null,
				'FECHA_TRANSACCION' => null,
				'ISERROR' =>  true,
				'MSG_INFO' => $ex->getMessage()
			);
	  	}
		return $response_data;		
	}

	function AddNewExp($EntSecurity = array(), $ArcAddExpediente = array(), $ExpInteresado = array())
	{
		$response_data = array ();
		$fecha_transaccion = date('Y-m-d G:i:s');
		$simad_util = new simad_util();
		//*******************************************************************************************************************
		$infoxml = file_get_contents("php://input");
		//*******************************************************************************************************************
		try
		{
			$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
			if($usuario_ws['isError'])
			{
				return array 
				(
					'CONSECUTIVO_ID' => null,
					'NUMERO_EXPEDIENTE' => null,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  false,
					'MSG_INFO' => $usuario_ws['message']
				);
			}
			//***************************************************************************************************************
				$origen = 0;
				$unidaddoc_anterior = null;
				//************************************************************************************************************************
				$usuariologuiado = $usuario_ws['object']->getUsuarioId();
				$nuid_responsable = isset($ArcAddExpediente['NUID_RESPONSABLE']) ? trim($ArcAddExpediente['NUID_RESPONSABLE']) : null;
				$cuser_responsable = CargoUsuarioPeer::getCargoUsuarioByNuidUser($nuid_responsable, true);
				$id_responsable = $cuser_responsable->getUsuarioId();
				$id_creador = $usuariologuiado;
				$id_inventariador = $cuser_responsable->getUsuarioId();
				//************************************************************************************************************************
				$usuario_responsable = UsuarioPeer::retrieveByPK($id_responsable);
				$volumen = isset($ArcAddExpediente['VOLUMEN']) ? trim($ArcAddExpediente['VOLUMEN']) : 1;
				//************************************************************************************************************************
				//************************************************************************************************************************
				$str_fase_archivo = isset($ArcAddExpediente['FASE_ARCHIVO']) ? trim($ArcAddExpediente['FASE_ARCHIVO']) : null;
				$obj_fase_archivo = LocalizacionUnidadDocumentalPeer::getLocalizacionByDesc($str_fase_archivo);
				$fase_archivo = $obj_fase_archivo->getLocalizacionunidaddocumentalId();

				$sede_regional = $usuario_responsable->getRegionalId();
				$str_soporte_documental = isset($ArcAddExpediente['SOPORTE_DOCUMENTAL']) ? trim($ArcAddExpediente['SOPORTE_DOCUMENTAL']) : null;
				$obj_soporte_documental = SoporteUnidadDocumentalPeer::getSoporteUnidadDocDesp($str_soporte_documental);
				$soporte_documental = $obj_soporte_documental->getSoporteunidaddocumentalId();

				$str_estado_documental = isset($ArcAddExpediente['ESTADO_DOCUMENTAL']) ? trim($ArcAddExpediente['ESTADO_DOCUMENTAL']) : null;
				$obj_estado_documental = EstadoUnidadDocumentalPeer::getEstadoByDesc($str_estado_documental);
				$estado_documental = $obj_estado_documental->getEstadounidaddocumentalId();
		
				$frecuencia_documental = isset($ArcAddExpediente['FRECUENCIA_DOCUMENTAL']) ? trim($ArcAddExpediente['FRECUENCIA_DOCUMENTAL']) : 1;
				if(isset($ArcAddExpediente['FRECUENCIA_DOCUMENTAL']))
				{
					$str_frecuencia_documental = trim($ArcAddExpediente['FRECUENCIA_DOCUMENTAL']);
					$obj_frecuencia_documental = FrecuenciaConsultaPeer::getFrecuenciaByDesc($str_frecuencia_documental);
					$frecuencia_documental = $obj_frecuencia_documental->getFrecuenciaconsultaId();
				}
				else
				{
					$frecuencia_documental = 1;
				}

				if(isset($ArcAddExpediente['MEDIO_CONSERVACION']))
				{
					$str_medio_conservacion = trim($ArcAddExpediente['MEDIO_CONSERVACION']);
					$obj_medio_conservacion = UnidadConservadoraPeer::getUnidadByDesc($str_medio_conservacion);
					$medio_conservacion = $obj_medio_conservacion->getUnidadconservadoraId();
				}
				else
				{
					$medio_conservacion = 1;
				}

				$codigo_barras = isset($ArcAddExpediente['NUMERO_EXPEDIENTE']) ? trim($ArcAddExpediente['NUMERO_EXPEDIENTE']) : '';
				$codigo_subserie = isset($ArcAddExpediente['CODIGO_SUBSERIE']) ? trim($ArcAddExpediente['CODIGO_SUBSERIE']) : 1; //CONFIRMAR VALIDACION

				if(empty($codigo_subserie))
				{
					return responseErrorDataExp('El campo CODIGO_SUBSERIE es obligatorio');
				}

				$subserie_array = SubseriePeer::getSubserieByCodigo($codigo_subserie); 
				$subserie_obj = $subserie_array[0];
				$subserie_id = $subserie_obj->getSubserieId(); 
				$regional_id = $usuario_responsable->getRegionalId();
				
				$titulo = trim($ArcAddExpediente['NOMBRE_EXPEDIENTE']);
				$contenido = trim($ArcAddExpediente['CONTENIDO']);
				$folios = trim($ArcAddExpediente['FOLIOS']);
				$notas = trim($ArcAddExpediente['NOTAS']);
				$volumen = isset($ArcAddExpediente['VOLUMEN']) ? trim($ArcAddExpediente['VOLUMEN']) : 1;
				$numero_caja = trim($ArcAddExpediente['NUMERO_CAJA']);
				$numero_identificacion = isset($ArcAddExpediente['NUMERO_IDENTIFICACION']) ? trim($ArcAddExpediente['NUMERO_IDENTIFICACION']) : null;
				$fecha_apertura = isset($ArcAddExpediente['FECHA_APERTURA']) ? trim($ArcAddExpediente['FECHA_APERTURA']) : null;
				$fecha_cierre = isset($ArcAddExpediente['FECHA_CIERRE']) ? trim($ArcAddExpediente['FECHA_CIERRE']) : null;
				$ubicacion_gestion = trim($ArcAddExpediente['UBICACIONENGESTION']);
				$ubicacion_central = trim($ArcAddExpediente['UBICACIONENCENTRAL']);
				$ubicacion_historico = trim($ArcAddExpediente['UBICACIONENHISTORICO']);

				$numero_caja = isset($ArcAddExpediente['NUMERO_CAJA']) ? trim($ArcAddExpediente['NUMERO_CAJA']) : null;

				// ***************************************************************************************
				$usuario_ws = $usuario_ws['object'];
				$wslog = WebserviceLogPeer::addLogWs("AddNewDocumentoExp",$infoxml,null,1,"Consumen Servicio web SGDEA => ".($numero_expediente),"Ejecuta Exitoso => ".($numero_expediente),$usuario_ws->getPrimaryKey());
				//******************************************************************
				//validaciones FKs y campos obligatorios
				if(empty($fase_archivo))
				{
					return responseErrorDataExp('El campo Fase Archivo es obligatorio');
				}
				if(empty($soporte_documental))
				{
					return responseErrorDataExp('El campo Soporte Documental es obligatorio');
				}
				if(empty($estado_documental))
				{
					return responseErrorDataExp('El campo Estado Documental es obligatorio');
				}
				if(empty($frecuencia_documental))
				{
					return responseErrorDataExp('El campo Frecuencia Documental es obligatorio');
				}
				if(empty($medio_conservacion))
				{
					return responseErrorDataExp('El campo Medio Conservacion es obligatorio');
				}
				if(empty($subserie_id))
				{
					return responseErrorDataExp('El campo Subserie Id es obligatorio');
				}

				if($soporte_documental == null)
				{
					//SOPORTE_UNIDAD_DOCUMENTAL.SOPORTEUNIDADDOCUMENTAL_ID = 1  (DESCRIPCION = PAPEL)
					$soporte_documental = 1;  
				}
				if($estado_documental == null)
				{
					//ESTADO_UNIDAD_DOCUMENTAL.ESTADOUNIDADDOCUMENTAL_ID = 1  (DESCRIPCION = ACTIVO)
					$estado_documental = 1;  
				}

				/********************************************************************************************************************** */
				// INTERESADOS  - INICIO
				/********************************************************************************************************************** */
				$comlist_interesados = array();
				$laddnew_interesados = array();
				$interesados_nuids = array();

				foreach ($ExpInteresado as $info_list)   
				{
					if(simad_util::array_check($info_list, 'PRIMER_NOMBRE') && simad_util::array_check($info_list, 'PRIMER_APELLIDO') && simad_util::array_check($info_list,'NUMERO_IDENTIFICACION'))
					{
						if(!trim($info_list['NUMERO_IDENTIFICACION'])) //si no existe el nro de identificacion, da error
						{
							return responseErrorDataExp('El numero de identificación del interesado no es valido');
							exit;
						}
						//********************************************************************************************************
						$interesados_nuids[] = trim($info_list['NUMERO_IDENTIFICACION']);
						//********************************************************************************************************
						$interesado_id = InteresadosPeer::existsIntByNameAndNuid($info_list['PRIMER_NOMBRE'], $info_list['PRIMER_APELLIDO'], $info_list['NUMERO_IDENTIFICACION']);
						if($interesado_id != null)
						{
							$comlist_interesados[] = $interesado_id;
						}
						elseif(simad_util::array_check($info_list,'TIPO_IDENTIFICACION'))
						{
							$tipouid_id = TipoIdentificacionPeer::getTipoIdentificacionPkBySigla(trim($info_list['TIPO_IDENTIFICACION']));
							if($tipouid_id == null)
							{
								return responseErrorDataExp('El tipo de identificación del interesado no es un valor valido');
							}
							//****************************************************************************************************
							$info_list['TIPO_IDENTIFICACION'] = $tipouid_id;
							$optional_fileds = array('TIPO_GENERO' => true, 'EMAIL' => true);
							$isValidIntInfo = InteresadosPeer::validateInfoNewInteresado($info_list, $optional_fileds);
							if($isValidIntInfo['IsValid'] == true)
							{
								$laddnew_interesados[] = $info_list;
							}
							else
							{
								return responseErrorDataExp($isValidIntInfo['MsgError']);
								exit;
							}
						}
						else
						{
							$info_list['TIPO_IDENTIFICACION'] = 5;
							$isValidIntInfo = InteresadosPeer::validateInfoNewInteresado($info_list);
							if($isValidIntInfo['IsValid'] == true)
							{
								$laddnew_interesados[] = $info_list;
							}
							else
							{
								return responseErrorDataExp($isValidIntInfo['MsgError']);
								exit;
							}
						}
					}
					else
					{
						return responseErrorDataExp('El nombre o numero de identificación del interesado no es valido');
						exit;
					}
				}
				//***************************************************************************************************************
				if(count($comlist_interesados) <= 0 && count($laddnew_interesados) <= 0)
				{ 
					return responseErrorDataExp('Debe enviar como minimo un interesado');
				}
				/********************************************************************************************************************** */
				// INTERESADOS  - FIN
				/********************************************************************************************************************** */
				$params = array();
				$params['codigo_barras'] = $codigo_barras;
				$params['usuariologuiado'] = $usuariologuiado;
				$params['id_responsable'] = $id_responsable;
				$params['id_creador'] = $id_creador;
				$params['id_inventariador'] = $id_inventariador;
				$params['usuario_responsable'] = $usuario_responsable;
				$params['volumen'] = $volumen; // ????
				//FK...
				$params['fase_archivo'] = $fase_archivo;  //LA FASE ARCHIVO ES LA MISMA UBICACION!!!
				$params['sede_regional'] = $sede_regional;
				$params['soporte_documental'] = $soporte_documental;
				$params['estado_documental'] = $estado_documental;
				$params['frecuencia_documental'] = $frecuencia_documental;
				$params['medio_conservacion'] = $medio_conservacion;
				$params['subserie_id'] = $subserie_id;
				$params['regional_id'] = $regional_id;
				$params['titulo'] = $titulo;
				$params['contenido'] = $contenido;
				$params['folios'] = $folios;
				$params['notas'] = $notas;
				$params['volumen'] = $volumen;
				$params['numero_caja'] = $numero_caja;
				$params['fecha_apertura'] = $fecha_apertura;
				$params['fecha_cierre'] = $fecha_cierre;
				$params['numero_identificacion'] = $numero_identificacion;
				$params['numero_caja'] = $numero_caja;
				$params['already_interesados'] = $comlist_interesados;
				$params['new_interesados'] = $laddnew_interesados;

				//************************************************************************* */
				$response = UnidadDocumentalPeer::addUnidadDocumental($params);
				//************************************************************************* */

				if($response['error'])
				{
					return responseErrorDataExp($response['message']);
				}	
				
				$unidad_documental = $response['object'];

			$response_data = array 
			( 
				'CONSECUTIVO_ID' => $unidad_documental->getPrimaryKey(),
				'NUMERO_EXPEDIENTE' => $unidad_documental->getCodigoBarras(),
				'FECHA_TRANSACCION' => $fecha_transaccion,
				'ISERROR' =>  False,
				'MSG_INFO' => 'Expediente creado exitosamente'
			);
		}
		catch(SoapFault $ex) 
		{
			$response_data = array (
				'CONSECUTIVO_ID' => null,
				'NUMERO_EXPEDIENTE' => null,
				'FECHA_TRANSACCION' => null,
				'ISERROR' =>  true,
				'MSG_INFO' => $ex->getMessage()
			);
	  	}
		catch(Exception $ex)
		{
			$response_data = array (
				'CONSECUTIVO_ID' => null,
				'NUMERO_EXPEDIENTE' => null,
				'FECHA_TRANSACCION' => null,
				'ISERROR' =>  true,
				'MSG_INFO' => $ex->getMessage()
			);
	  	}
		return $response_data;		
	}


	function SearchExp($EntSecurity = array(), $TermSearchExpediente = array())
	{
		$response_data = array ();
		$fecha_transaccion = date('Y-m-d G:i:s');
		$simad_util = new simad_util();
		//*******************************************************************************************************************
		$infoxml = file_get_contents("php://input");
		//*******************************************************************************************************************
		try
		{
			$usuario_ws = UsuarioPeer::autenticateUserWs($EntSecurity);
			if($usuario_ws['isError'])
			{
				return array 
				(
					'CONSECUTIVO_ID' => null,
					'NUMERO_EXPEDIENTE' => null,
					'FECHA_TRANSACCION' => $fecha_transaccion,
					'ISERROR' =>  false,
					'MSG_INFO' => $usuario_ws['message']
				);
			}
			//***************************************************************************************************************			
			$origen = 0;
			$unidaddoc_anterior = null;
			//************************************************************************************************************************
			$usuariologuiado = $usuario_ws['object']->getUsuarioId();

			$numero_expediente = isset($TermSearchExpediente['NUMERO_EXPEDIENTE']) ? trim($TermSearchExpediente['NUMERO_EXPEDIENTE']) : null;
			$codigo_dependencia = isset($TermSearchExpediente['CODIGO_DEPENDENCIA']) ? trim($TermSearchExpediente['CODIGO_DEPENDENCIA']) : null;
			$codigo_subserie = isset($TermSearchExpediente['CODIGO_SUBSERIE']) ? trim($TermSearchExpediente['CODIGO_SUBSERIE']) : null;
			$str_fase_archivo = isset($TermSearchExpediente['FASE_ARCHIVO']) ? trim($TermSearchExpediente['FASE_ARCHIVO']) : null; 

			//campos opcionales
			$identificacion_interesado = isset($TermSearchExpediente['IDENTIFICACION_INTERESADO']) ? trim($TermSearchExpediente['IDENTIFICACION_INTERESADO']) : null;
			$pnombre_interesado = isset($TermSearchExpediente['PNOMBRE_INTERESADO']) ? trim($TermSearchExpediente['PNOMBRE_INTERESADO']) : null;
			$papellido_interesado = isset($TermSearchExpediente['PAPELLIDO_INTERESADO']) ? trim($TermSearchExpediente['PAPELLIDO_INTERESADO']) : null;

			//validaciones FKs y campos obligatorios
			if(empty($numero_expediente))
			{
				//return responseErrorDataExp('El campo Numero Expediente es obligatorio');
			}

			if(empty($codigo_dependencia) && empty($codigo_subserie))
			{
				//return responseErrorDataExp('Es requerido uno de los dos campos: Codigo Dependencia o Codigo Subserie');
			} 
			
			if(empty($str_fase_archivo))
			{
				//return responseErrorDataExp('El campo Fase Archivo es obligatorio');
			}
			$obj_fase_archivo = !empty($str_fase_archivo) ? LocalizacionUnidadDocumentalPeer::getLocalizacionByDesc($str_fase_archivo) : null;

			if($obj_fase_archivo == null)
			{
				//return responseErrorDataExp("La fase de archivo no se encuentra en el SGDEA"); 
			}

			$int_fase_archivo = $obj_fase_archivo != null ? $obj_fase_archivo->getLocalizacionunidaddocumentalId() : null; 

			$array_unidad_documental = UnidadDocumentalPeer::getUnidadDocumentalBySearch($numero_expediente, $codigo_dependencia, $codigo_subserie, $int_fase_archivo, $identificacion_interesado, $pnombre_interesado, $papellido_interesado);

			if($array_unidad_documental['error'])
			{
				return responseErrorDataExp($array_unidad_documental['message']);
			}	
			
			$pre_unidad_documental = $array_unidad_documental['object'];

			//*********************INICIO FOR EACH MASIVA ********************************** */
			$list_expedientes = array();
			foreach($pre_unidad_documental as $exp_row)
			{
			//*********************INICIO  CONTENIDO_UNIDAD_DOCUMENTAL*************************** */
					$row_list_expedientes['DEPENDENCIA'] = $exp_row->getSubserie()->getSerie()->getDependencia()->getNombreCustomFull();
					$row_list_expedientes['CODIGO_DEPENDENCIA'] = $exp_row->getSubserie()->getSerie()->getDependencia()->getCodigo();
					$row_list_expedientes['NUMERO_EXPEDIENTE'] = $exp_row->getCodigoBarras();
					$row_list_expedientes['FECHA_CREACION'] = $exp_row->getFechaCreacion();
					$row_list_expedientes['FECHA_APERTURA'] = $exp_row->getFechaApertura();
					$row_list_expedientes['FECHA_CIERRE'] = $exp_row->getFechaCierre();
					$row_list_expedientes['NOMBRE_SERIE'] = $exp_row->getSubserie()->getSerie()->getDescripcion();
					$row_list_expedientes['CODIGO_SERIE'] = $exp_row->getSubserie()->getSerie()->getCodigo();
					$row_list_expedientes['NOMBRE_SUBSERIE'] = $exp_row->getSubserie()->getDescripcion();
					$row_list_expedientes['CODIGO_SUBSERIE'] = $exp_row->getSubserie()->getCodigo();
					$row_list_expedientes['FASE_ARCHIVO'] = $exp_row->getLocalizacionUnidadDocumental()->getDescripcion();
					$row_list_expedientes['NOMBRE_EXPEDIENTE'] = $exp_row->getTitulo();
					$row_list_expedientes['CONSECUTIVO_ID'] = $exp_row->getPrimaryKey();

					$unidad_documental_id = $exp_row->getUnidaddocumentalId();
			$contenido_unidad_documental = ContenidoUnidadDocumentalPeer::getContUnidadDocByUDocId($unidad_documental_id);
			
			$list_documentos = array();
			foreach($contenido_unidad_documental as $row)
			{
				$xguid = simad_util::create_guid(basename($row->getRuta()));
				$row_list_documentos['DESCRIPCION'] = $row->getDescripcion();
				$row_list_documentos['FECHA_CREACION'] = $row->getFechaCreacion();
				$row_list_documentos['FECHA_DOCUMENTO'] = $row->getFechaDocumento();					
				$row_list_documentos['CODIGO_TIPODOC'] = $row->getTipoDocumental()->getCodigo();

				if($row->getVinculoRegistro())
				{
					$url_modulo = preg_split("/[\/]+/", trim($row->getRuta()), -1, PREG_SPLIT_NO_EMPTY);

					$tipo_consecutivo = 0;
					$list_attach = array();
					$object_pk = -1;
					//************************************************************************************************
					if($url_modulo[0] == 'recibida.php')
					{
						$tipo_consecutivo = 2;
						$object_pk = end($url_modulo);
					}
					else if($url_modulo[0] == 'interna.php')
					{
						$tipo_consecutivo = 3;
						$object_pk = end($url_modulo);
					}
					else if($url_modulo[0] == 'enviada.php')
					{
						$tipo_consecutivo = 1;
						$object_pk = end($url_modulo);
					}
					else
					{
						$tipo_consecutivo = 0;
					}
					//************************************************************************************************
					switch ($tipo_consecutivo) 
					{
						case 1://enviadas
							$com_enviada =  ComEnviadaPeer::retrieveByPK($object_pk);
							if($com_enviada == null){ break; }
							//***************************************************************************************
							$list_attach = $com_enviada->getListDigitDocument(); // array de mas de 1 ..
							break;
						case 2://recibidas
							$com_recibida =  ComRecibidaPeer::retrieveByPK($object_pk);
							if($com_recibida == null){ break; }
							//***************************************************************************************
							$list_attach = $com_recibida->getListDigitDocument();
							break;
						case 3://interna
							$com_interna =  ComInternaPeer::retrieveByPK($object_pk);
							if($com_interna == null){ break; }
							//***************************************************************************************
							$list_attach = $com_interna->getListDigitDocument(); // array de mas de 1 ..
							break;
						default:
							$list_attach = array();
							break;
					}
					//************************************************************************************************
					//var_dump($list_attach); exit();
					$array_comdocs = array();
					$array_normal = array(); 
					foreach($list_attach as $adjunto)
					{
						$array_normal['GUID'] = $adjunto['GUID'];
						$array_normal['NOMBRE_ARCHIVO'] = $adjunto['NOMBRE_ARCHIVO'];
						$array_normal['TIPO_ATTACHMENT'] = $adjunto['TIPO_ATTACHMENT'];
						$array_normal['URL'] = $adjunto['URL'];
						$array_normal['URL_DOWNLOAD'] = $adjunto['URL_DOWNLOAD'];

						$array_comdocs[] = $array_normal; //aqui SI va acumulando cada iteracion...
					} 
					$row_list_documentos['ADJUNTOS'] = array($array_comdocs);
				}
				else
				{
					$array_normal['GUID'] = $xguid;
					$array_normal['NOMBRE_ARCHIVO'] = basename($row->getRuta());
					$array_normal['TIPO_ATTACHMENT'] = 'ANEXO';
					$array_normal['URL'] = $row->getUrlTokenTrustImageByObject($xguid);
					$array_normal['URL_DOWNLOAD'] = $row->getUrlTokenTrustImageByObject($xguid);

					$row_list_documentos['ADJUNTOS'] = array($array_normal);
				} 				
				$list_documentos[] = $row_list_documentos;
			}
				$row_list_expedientes['LISTA_DOCUMENTOS'] = $list_documentos;
				$list_expedientes[] = $row_list_expedientes;
			}
			$response_data = array 
			( 
				'LISTA_EXPEDIENTES' => array($list_expedientes),
				'ISERROR' =>  false,
				'MSG_INFO' => 'Expedientes encontrados exitosamente'
			);
		}
		catch(SoapFault $ex) 
		{
			$response_data = array (
				'LISTA_EXPEDIENTES' => array(),
				'ISERROR' =>  true,
				'MSG_INFO' => $ex->getMessage()
			);
	  	}
		catch(Exception $ex)
		{
			$response_data = array (
				'LISTA_EXPEDIENTES' => array(),
				'ISERROR' =>  true,
				'MSG_INFO' => $ex->getMessage()
			);
	  	}
		return $response_data;		
	}
?>